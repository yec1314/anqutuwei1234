#!/system/bin/sh
# 模块开机服务
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MODDIR="${0%/*}"
MOD_DIR="$MODDIR"

# 加载统一路径
. "$MOD_DIR/scripts/lib_paths.sh"

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 5

# 老用户首次迁移（一次性）
webui_migrate_legacy
# 初始化目录 + 清空 runtime
webui_init_dirs
webui_clean_runtime

LOGFILE="$WEBUI_SERVICE_LOG"
SETTINGS_FILE="$WEBUI_SETTINGS"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOGFILE"
}

log "===== 开机服务启动 ====="

chmod +x "$MODDIR/scripts/"*.sh 2>/dev/null
chmod +x "$MODDIR/curl/curl" 2>/dev/null

log "执行机型伪装恢复"
sh "$MODDIR/scripts/spoof.sh" boot_apply >/dev/null 2>&1

log "执行序列号修改恢复"
sh "$MODDIR/scripts/serial.sh" boot_apply >/dev/null 2>&1

log "执行特征隐藏服务"
sh "$MODDIR/scripts/persist-hide.sh" boot_apply >/dev/null 2>&1

log "启动防标记看护（boot 常驻）"
setsid sh "$MODDIR/scripts/anti_mark_watchdog.sh" </dev/null >/dev/null 2>&1 &

log "优化 inotify 参数"
sh "$MODDIR/scripts/cleaner.sh" inotify >/dev/null 2>&1

log "统计使用次数"
sh "$MODDIR/scripts/Statistics.sh"

get_setting() {
    grep "^$1=" "$SETTINGS_FILE" 2>/dev/null | head -1 | cut -d'=' -f2-
}

BOOT_CLEAN=$(get_setting auto_clean_on_boot)
[ -z "$BOOT_CLEAN" ] && BOOT_CLEAN=0
if [ "$BOOT_CLEAN" = "1" ]; then
    MODE=$(get_setting clean_mode)
    log "开机自动清理（模式: ${MODE:-deep}）"
    sh "$MODDIR/scripts/cleaner.sh" "${MODE:-deep}" >/dev/null 2>&1
fi

START_EN=$(get_setting auto_clean_on_codev_start)
STOP_EN=$(get_setting auto_clean_on_codev_stop)
if [ "$START_EN" = "1" ] || [ "$STOP_EN" = "1" ]; then
    log "启动进程监听"
    sh "$MODDIR/scripts/monitor.sh" start &
fi

log "开机兜底恢复所有被隐藏的应用"
sh "$MODDIR/scripts/app_hide.sh" restore_all >/dev/null 2>&1

APP_HIDE_EN=$(get_setting app_hide_daemon_enabled)
if [ "$APP_HIDE_EN" = "1" ]; then
    log "启动应用控制看护（boot 常驻）"
    setsid sh "$MODDIR/scripts/app_hide_watchdog.sh" </dev/null >/dev/null 2>&1 &
fi

log "后台同步机型库"
( sh "$MODDIR/scripts/presets.sh" sync >/dev/null 2>&1 ) &

log "后台扫描应用列表"
( sh "$MODDIR/scripts/scan_apps.sh" >/dev/null 2>&1 ) &

log "===== 开机服务初始化完成 ====="
