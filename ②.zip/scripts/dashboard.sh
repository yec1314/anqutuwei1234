#!/system/bin/sh
# 首页仪表盘 - 聚合各模块状态（并行优化版）
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs

# 临时输出目录（每次运行用 $$ 隔离）
TMP_DIR="$WEBUI_RUNTIME_DIR/dashboard_$$"
mkdir -p "$TMP_DIR" 2>/dev/null

# 安全读取 JSON 字段
get_field() {
    local json="$1"
    local key="$2"
    echo "$json" | grep -oE "\"${key}\"\s*:\s*\"?[^,\"\\}]+\"?" | head -1 | \
        sed 's/.*:\s*"\?//;s/"\?$//' | tr -d ' \n\r'
}

# ============ 各模块查询函数（每个写到自己的临时文件） ============
fetch_antimark() {
    local out enabled running game
    out=$(sh "$MOD_DIR/scripts/anti-mark.sh" status 2>/dev/null)
    enabled=$(get_field "$out" "enabled"); [ -z "$enabled" ] && enabled="0"
    running=$(get_field "$out" "running"); [ -z "$running" ] && running="false"
    game=$(get_field "$out" "game"); [ -z "$game" ] && game="-"
    printf '"antimark":{"enabled":"%s","running":"%s","game":"%s"}' "$enabled" "$running" "$game" > "$TMP_DIR/antimark"
}

fetch_persist() {
    local out enabled running mounted
    out=$(sh "$MOD_DIR/scripts/persist-hide.sh" status 2>/dev/null)
    enabled=$(get_field "$out" "enabled"); [ -z "$enabled" ] && enabled="0"
    running=$(get_field "$out" "running"); [ -z "$running" ] && running="false"
    mounted=$(get_field "$out" "mounted"); [ -z "$mounted" ] && mounted="0"
    printf '"persist":{"enabled":"%s","running":"%s","mounted":%s}' "$enabled" "$running" "$mounted" > "$TMP_DIR/persist"
}

fetch_spoof() {
    local out active label
    out=$(sh "$MOD_DIR/scripts/spoof.sh" status 2>/dev/null)
    active=$(get_field "$out" "active"); [ -z "$active" ] && active="false"
    label=$(get_field "$out" "label"); [ -z "$label" ] && label="原机型"
    label=$(echo "$label" | sed 's/"/\\"/g')
    printf '"spoof":{"active":"%s","label":"%s"}' "$active" "$label" > "$TMP_DIR/spoof"
}

fetch_touch() {
    local out profile daemon
    out=$(sh "$MOD_DIR/scripts/touch_rate.sh" status 2>/dev/null)
    profile=$(get_field "$out" "profile"); [ -z "$profile" ] && profile="default"
    daemon=$(get_field "$out" "daemon"); [ -z "$daemon" ] && daemon="false"
    printf '"touch":{"profile":"%s","daemon":"%s"}' "$profile" "$daemon" > "$TMP_DIR/touch"
}

fetch_app_daemon() {
    local out running pid
    out=$(sh "$MOD_DIR/scripts/app_hide.sh" daemon_status 2>/dev/null)
    running=$(get_field "$out" "running"); [ -z "$running" ] && running="false"
    pid=$(get_field "$out" "pid"); [ -z "$pid" ] && pid="0"
    printf '"app_daemon":{"running":"%s","pid":"%s"}' "$running" "$pid" > "$TMP_DIR/app_daemon"
}

fetch_apkhide() {
    local out count
    out=$(sh "$MOD_DIR/scripts/app_apkhide.sh" status 2>/dev/null)
    count=$(get_field "$out" "hidden_count"); [ -z "$count" ] && count="0"
    printf '"apkhide":{"count":%s}' "$count" > "$TMP_DIR/apkhide"
}

fetch_serial() {
    local out modified current
    out=$(sh "$MOD_DIR/scripts/serial.sh" info 2>/dev/null)
    modified=$(get_field "$out" "modified"); [ -z "$modified" ] && modified="false"
    current=$(get_field "$out" "current"); [ -z "$current" ] && current="-"
    printf '"serial":{"modified":"%s","current":"%s"}' "$modified" "$current" > "$TMP_DIR/serial"
}

fetch_android_id() {
    local out modified
    out=$(sh "$MOD_DIR/scripts/android_id.sh" status 2>/dev/null)
    modified=$(get_field "$out" "modified"); [ -z "$modified" ] && modified="false"
    printf '"android_id":{"modified":"%s"}' "$modified" > "$TMP_DIR/android_id"
}

fetch_mac() {
    local out modified iface current
    out=$(sh "$MOD_DIR/scripts/mac.sh" info 2>/dev/null)
    modified=$(get_field "$out" "modified"); [ -z "$modified" ] && modified="false"
    iface=$(get_field "$out" "iface"); [ -z "$iface" ] && iface="-"
    current=$(get_field "$out" "current"); [ -z "$current" ] && current="-"
    printf '"mac":{"modified":"%s","iface":"%s","current":"%s"}' "$modified" "$iface" "$current" > "$TMP_DIR/mac"
}

fetch_module() {
    local ver name
    ver=$(grep "^version=" "$MOD_DIR/module.prop" 2>/dev/null | cut -d= -f2)
    name=$(grep "^name=" "$MOD_DIR/module.prop" 2>/dev/null | cut -d= -f2)
    [ -z "$ver" ] && ver="-"
    [ -z "$name" ] && name="CITADEL"
    printf '"module":{"name":"%s","version":"%s"}' "$name" "$ver" > "$TMP_DIR/module"
}

# ============ 并行启动所有查询 ============
fetch_module &
fetch_antimark &
fetch_persist &
fetch_spoof &
fetch_touch &
fetch_app_daemon &
fetch_apkhide &
fetch_serial &
fetch_android_id &
fetch_mac &

# 等待所有后台任务完成
wait

# ============ 拼接输出 ============
printf '{"ok":true,'
[ -f "$TMP_DIR/module" ] && cat "$TMP_DIR/module"; printf ','
[ -f "$TMP_DIR/antimark" ] && cat "$TMP_DIR/antimark"; printf ','
[ -f "$TMP_DIR/persist" ] && cat "$TMP_DIR/persist"; printf ','
[ -f "$TMP_DIR/spoof" ] && cat "$TMP_DIR/spoof"; printf ','
[ -f "$TMP_DIR/touch" ] && cat "$TMP_DIR/touch"; printf ','
[ -f "$TMP_DIR/app_daemon" ] && cat "$TMP_DIR/app_daemon"; printf ','
[ -f "$TMP_DIR/apkhide" ] && cat "$TMP_DIR/apkhide"; printf ','
[ -f "$TMP_DIR/serial" ] && cat "$TMP_DIR/serial"; printf ','
[ -f "$TMP_DIR/android_id" ] && cat "$TMP_DIR/android_id"; printf ','
[ -f "$TMP_DIR/mac" ] && cat "$TMP_DIR/mac"
printf '}\n'

# 清理临时目录
rm -rf "$TMP_DIR" 2>/dev/null
