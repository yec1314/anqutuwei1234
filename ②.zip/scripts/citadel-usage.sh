#!/system/bin/sh

set -eu

BASE_URL="${CITADEL_API_BASE:-https://baolei.icu}"
ACTION="${1:-visit}"
CLIENT_ID="${2:-}"
CLIENT_ID_FILE="${CITADEL_CLIENT_ID_FILE:-/data/local/tmp/citadel-client-id}"

urlencode() {
  value="$1"
  if command -v python3 >/dev/null 2>&1; then
    python3 -c 'import sys, urllib.parse; print(urllib.parse.quote(sys.argv[1], safe=""))' "$value"
    return
  fi

  printf '%s' "$value" | sed \
    -e 's/%/%25/g' \
    -e 's/ /%20/g' \
    -e 's/#/%23/g' \
    -e 's/&/%26/g' \
    -e 's/+/%2B/g' \
    -e 's/?/%3F/g' \
    -e 's/=/%3D/g'
}

request() {
  url="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL "$url"
    return
  fi

  if command -v wget >/dev/null 2>&1; then
    wget -qO- "$url"
    return
  fi

  echo "curl or wget is required" >&2
  exit 127
}

if [ -z "$CLIENT_ID" ]; then
  if [ -r "$CLIENT_ID_FILE" ]; then
    CLIENT_ID="$(sed -n '1p' "$CLIENT_ID_FILE")"
  else
    CLIENT_ID="android-shell-$(date +%s 2>/dev/null || sed 's/[. ].*//' /proc/uptime 2>/dev/null || echo 0)"
    printf '%s\n' "$CLIENT_ID" > "$CLIENT_ID_FILE" 2>/dev/null || true
  fi

  if [ -z "$CLIENT_ID" ]; then
    CLIENT_ID="android-shell-$(date +%s 2>/dev/null || echo 0)"
  fi
fi

case "$ACTION" in
  visit|view)
    request "$BASE_URL/api/usage/visit?source=shell"
    ;;
  ping|heartbeat)
    request "$BASE_URL/api/usage/heartbeat?id=$(urlencode "$CLIENT_ID")&source=shell"
    ;;
  stats)
    request "$BASE_URL/api/usage/stats"
    ;;
  *)
    echo "usage: CITADEL_API_BASE=https://example.com $0 [visit|heartbeat|stats] [client_id]" >&2
    echo "default client id file: $CLIENT_ID_FILE" >&2
    exit 2
    ;;
esac
