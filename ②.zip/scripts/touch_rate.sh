#!/system/bin/sh
# 触控采样率提升脚本
# 作者: 呆呆 | QQ:891354018 | 群:774886621
# 用法:
#   sh touch_rate.sh set <profile>   设置触控采样率档位
#   sh touch_rate.sh status          查询当前档位
#   sh touch_rate.sh stop            停止循环守护并恢复默认

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
PROFILE_FILE="$WEBUI_TOUCH_PROFILE"
DAEMON_PIDFILE="$WEBUI_TOUCH_DAEMON_PID"
ACTION="$1"
PROFILE="$2"

. "$MOD_DIR/scripts/lib_log.sh"
init_log "touch"

log() {
    log_json "$1"
}

cmd_for() {
    case "$1" in
        125)  echo "touchHidlTest -c wo 0 26 0" ;;
        240)  echo "touchHidlTest -c wo 0 26 1" ;;
        360)  echo "touchHidlTest -c wo 0 26 12c" ;;
        600)  echo "touchHidlTest -c wo 0 26 258" ;;
        241)  echo "touchHidlTest -c wo 0 182 240" ;;
        361)  echo "touchHidlTest -c wo 0 26 c" ;;
        362)  echo "touchHidlTest -c wo 0 182 360" ;;
        *)    echo "" ;;
    esac
}

stop_daemon() {
    if [ -f "$DAEMON_PIDFILE" ]; then
        local pid=$(cat "$DAEMON_PIDFILE" 2>/dev/null | tr -d ' \n\r')
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            kill -9 "$pid" 2>/dev/null
        fi
        rm -f "$DAEMON_PIDFILE"
    fi
    # 清理残留同名进程
    local stray
    stray=$(pgrep -f "touch_daemon.sh" 2>/dev/null)
    if [ -n "$stray" ]; then
        echo "$stray" | while read -r p; do
            kill -9 "$p" 2>/dev/null
        done
    fi
}

start_daemon() {
    stop_daemon
    local script="$MOD_DIR/scripts/touch_daemon.sh"
    [ -f "$script" ] || return 1

    # 使用 setsid nohup 脱离 WebUI 会话，防止关闭 KSU 后进程被杀
    if command -v setsid >/dev/null 2>&1; then
        setsid nohup sh "$script" </dev/null >/dev/null 2>&1 &
    elif command -v nohup >/dev/null 2>&1; then
        nohup sh "$script" </dev/null >/dev/null 2>&1 &
    else
        sh "$script" </dev/null >/dev/null 2>&1 &
    fi

    # 等待 PID 文件写入（daemon 脚本需要自己写 PID）
    local i=0
    while [ "$i" -lt 20 ]; do
        if [ -f "$DAEMON_PIDFILE" ]; then
            local pid
            pid=$(cat "$DAEMON_PIDFILE" 2>/dev/null | tr -d ' \n\r')
            if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
                log "循环守护已启动 (PID: $pid, setsid)"
                return 0
            fi
        fi
        sleep 0.1 2>/dev/null || sleep 1
        i=$((i + 1))
    done
    # 兜底：如果 daemon 没写 PID 文件，手动查找
    local found_pid
    found_pid=$(pgrep -f "touch_daemon.sh" 2>/dev/null | head -1)
    if [ -n "$found_pid" ]; then
        echo "$found_pid" > "$DAEMON_PIDFILE"
        log "循环守护已启动 (PID: $found_pid, fallback)"
        return 0
    fi
    log "循环守护启动失败"
    return 1
}

case "$ACTION" in
    set)
        [ -z "$PROFILE" ] && { echo '{"ok":false,"error":"missing profile"}'; exit 1; }
        if [ "$PROFILE" = "default" ]; then
            stop_daemon
            echo "default" > "$PROFILE_FILE"
            log "已恢复默认，停止循环守护"
            printf '{"ok":true,"profile":"default","msg":"已恢复默认触控采样率"}\n'
        else
            CMD=$(cmd_for "$PROFILE")
            if [ -z "$CMD" ]; then
                printf '{"ok":false,"error":"未知档位: %s"}\n' "$PROFILE"
                exit 1
            fi
            $CMD 2>/dev/null
            log "立即执行: $CMD"
            echo "$PROFILE" > "$PROFILE_FILE"
            start_daemon
            printf '{"ok":true,"profile":"%s","msg":"触控采样率已设置为 %s"}\n' "$PROFILE" "$PROFILE"
        fi
        ;;

    status)
        local cur="default"
        [ -f "$PROFILE_FILE" ] && cur=$(cat "$PROFILE_FILE" 2>/dev/null)
        [ -z "$cur" ] && cur="default"
        local daemon_running="false"
        if [ -f "$DAEMON_PIDFILE" ]; then
            local pid=$(cat "$DAEMON_PIDFILE")
            if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
                daemon_running="true"
            fi
        fi
        printf '{"ok":true,"profile":"%s","daemon":%s}\n' "$cur" "$daemon_running"
        ;;

    stop)
        stop_daemon
        echo "default" > "$PROFILE_FILE"
        log "手动停止守护并恢复默认"
        printf '{"ok":true,"msg":"已停止触控守护"}\n'
        ;;

    *)
        echo '{"ok":false,"error":"unknown action - use: set|status|stop"}'
        exit 1
        ;;
esac
