#!/system/bin/sh
# 机型伪装脚本
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
SETTINGS_FILE="$WEBUI_SETTINGS"
PROP_FILE="$WEBUI_SYSTEM_PROP"
PRESETS_CACHE="$WEBUI_PRESETS_CACHE"
CUSTOM_FILE="$WEBUI_CUSTOM_PRESETS"
. "$MOD_DIR/scripts/lib_log.sh"
init_log "spoof"
ACTION="$1"
MODEL_ID="$2"

read_setting() {
    local key="$1"
    [ -f "$SETTINGS_FILE" ] && grep -E "^${key}=" "$SETTINGS_FILE" | head -1 | cut -d'=' -f2-
}

write_setting() {
    local key="$1"
    local val="$2"
    [ ! -f "$SETTINGS_FILE" ] && touch "$SETTINGS_FILE"
    if grep -q "^${key}=" "$SETTINGS_FILE" 2>/dev/null; then
        sed -i "s|^${key}=.*|${key}=${val}|" "$SETTINGS_FILE"
    else
        echo "${key}=${val}" >> "$SETTINGS_FILE"
    fi
}

backup_orig_once() {
    if [ -z "$(read_setting 'orig_model')" ]; then
        write_setting "orig_model" "$(getprop ro.product.model)"
        write_setting "orig_brand" "$(getprop ro.product.brand)"
        write_setting "orig_manufacturer" "$(getprop ro.product.manufacturer)"
        write_setting "orig_device" "$(getprop ro.product.device)"
        write_setting "orig_name" "$(getprop ro.product.name)"
        write_setting "orig_marketname" "$(getprop ro.product.marketname)"
    fi
}

# 从 presets.json 提取指定 id 的所有 props，写入 system.prop
write_prop_from_preset() {
    local id="$1"

    [ ! -f "$PRESETS_CACHE" ] && {
        log_json "cache 不存在"
        return 1
    }

    > "$PROP_FILE"

    # awk 状态机：
    # state=0 还没找到目标 id
    # state=1 找到目标 id，等待 "props": {
    # state=2 在 props 块内，提取 key:value
    awk -v target="$id" '
    BEGIN { state=0 }

    state==0 {
        line = $0
        if (match(line, /"id"[[:space:]]*:[[:space:]]*"[^"]+"/)) {
            kv = substr(line, RSTART, RLENGTH)
            sub(/^"id"[[:space:]]*:[[:space:]]*"/, "", kv)
            sub(/"$/, "", kv)
            if (kv == target) state = 1
        }
        next
    }

    state==1 {
        if (index($0, "\"props\"") > 0 && index($0, "{") > 0) {
            state = 2
        }
        next
    }

    state==2 {
        # 退出条件：单独一行的 } 或 },
        line_trim = $0
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", line_trim)
        if (line_trim == "}" || line_trim == "},") {
            exit
        }

        # 匹配 "key": "value"（value 不能含未转义引号）
        line = $0
        # 提取 key
        if (!match(line, /"[^"]+"[[:space:]]*:[[:space:]]*"/)) next
        keypart = substr(line, RSTART, RLENGTH)
        sub(/^"/, "", keypart)
        sub(/"[[:space:]]*:[[:space:]]*"$/, "", keypart)

        # 提取 value（去掉 key:" 前缀，再去掉尾部 ", 或 "）
        val = line
        sub(/^[^"]*"[^"]*"[[:space:]]*:[[:space:]]*"/, "", val)
        sub(/"[[:space:]]*,?[[:space:]]*$/, "", val)

        if (keypart != "" && val != "") {
            print keypart "=" val
        }
    }
    ' "$PRESETS_CACHE" >> "$PROP_FILE"

    chmod 644 "$PROP_FILE"
    local n=$(wc -l < "$PROP_FILE" 2>/dev/null)
    log_json "$id 写入 $n 条 prop"

    [ "${n:-0}" -ge 3 ]
}

# 从 cache 提取该 id 的 label/brand/model（用于状态显示）
extract_meta() {
    local id="$1"
    [ ! -f "$PRESETS_CACHE" ] && return

    awk -v target="$id" '
    BEGIN { state=0; lbl=""; brd=""; mdl="" }
    state==0 {
        line = $0
        if (match(line, /"id"[[:space:]]*:[[:space:]]*"[^"]+"/)) {
            kv = substr(line, RSTART, RLENGTH)
            sub(/^"id"[[:space:]]*:[[:space:]]*"/, "", kv)
            sub(/"$/, "", kv)
            if (kv == target) state = 1
        }
        next
    }
    state==1 {
        if (lbl == "" && /"label"[[:space:]]*:/) {
            line = $0
            sub(/.*"label"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*/, "", line)
            lbl = line
        }
        if (brd == "" && /"brand"[[:space:]]*:/ && !/system|vendor|odm|bootimage/) {
            line = $0
            sub(/.*"brand"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*/, "", line)
            brd = line
        }
        if (mdl == "" && /"model"[[:space:]]*:/ && !/system|vendor|odm|bootimage/) {
            line = $0
            sub(/.*"model"[[:space:]]*:[[:space:]]*"/, "", line)
            sub(/".*/, "", line)
            mdl = line
        }
        if (/"props"[[:space:]]*:/) {
            print lbl "|" brd "|" mdl
            exit
        }
    }
    ' "$PRESETS_CACHE"
}

# ============ apply ============
cmd_apply() {
    local id="$1"
    [ -z "$id" ] && { echo '{"ok":false,"error":"missing id"}'; exit 1; }

    backup_orig_once

    local meta label brand model is_custom=0
    case "$id" in
        custom_*) is_custom=1 ;;
    esac

    if [ "$is_custom" = "1" ]; then
        meta=$(extract_custom_meta "$id")
    else
        meta=$(extract_meta "$id")
    fi
    label=$(echo "$meta" | cut -d'|' -f1)
    brand=$(echo "$meta" | cut -d'|' -f2)
    model=$(echo "$meta" | cut -d'|' -f3)

    local ok=0
    if [ "$is_custom" = "1" ]; then
        write_prop_from_custom "$id" && ok=1
    else
        write_prop_from_preset "$id" && ok=1
    fi

    if [ "$ok" = "1" ]; then
        write_setting "current_spoof" "$id"
        write_setting "current_spoof_label" "$label"
        write_setting "current_spoof_brand" "$brand"
        write_setting "current_spoof_model" "$model"
        printf '{"ok":true,"id":"%s","label":"%s","brand":"%s","model":"%s","msg":"已应用 %s，重启后生效"}\n' \
            "$id" "$label" "$brand" "$model" "$label"
    else
        if [ "$is_custom" = "1" ]; then
            echo '{"ok":false,"error":"应用失败：未找到该自定义机型，请重新添加"}'
        else
            echo '{"ok":false,"error":"应用失败：未找到该机型 props 数据，请重新同步机型库"}'
        fi
        exit 1
    fi
}

# ============ restore ============
cmd_restore() {
    > "$PROP_FILE"
    write_setting "current_spoof" ""
    write_setting "current_spoof_label" ""
    write_setting "current_spoof_brand" ""
    write_setting "current_spoof_model" ""
    echo '{"ok":true,"msg":"已恢复原机型，重启后生效"}'
}

# ============ status ============
cmd_status() {
    local cur=$(read_setting current_spoof)
    local label=$(read_setting current_spoof_label)
    local brand=$(read_setting current_spoof_brand)
    local model=$(read_setting current_spoof_model)
    local orig_brand=$(read_setting orig_brand)
    local orig_model=$(read_setting orig_model)

    [ -z "$orig_brand" ] && orig_brand=$(getprop ro.product.brand)
    [ -z "$orig_model" ] && orig_model=$(getprop ro.product.model)

    if [ -n "$cur" ]; then
        printf '{"active":true,"id":"%s","label":"%s","brand":"%s","model":"%s","orig_brand":"%s","orig_model":"%s"}\n' \
            "$cur" "$label" "$brand" "$model" "$orig_brand" "$orig_model"
    else
        printf '{"active":false,"id":"","label":"原机型","brand":"%s","model":"%s","orig_brand":"%s","orig_model":"%s"}\n' \
            "$orig_brand" "$orig_model" "$orig_brand" "$orig_model"
    fi
}

cmd_boot_apply() {
    local cur=$(read_setting current_spoof)
    if [ -n "$cur" ]; then
        backup_orig_once
        case "$cur" in
            custom_*)
                write_prop_from_custom "$cur" >/dev/null 2>&1 ;;
            *)
                write_prop_from_preset "$cur" >/dev/null 2>&1 ;;
        esac
    fi
}

# ============ 自定义机型 ============
# 自定义机型 ID 必须是 custom_XXX 形式，避免和官方库冲突
# 存储在 $CUSTOM_FILE 里，格式：
#   {"presets":[{"id":"custom_xxx","label":"自定义 1","brand":"...","model":"...","props":{...}}]}

# JSON 字符串转义（最小集：反斜杠 + 双引号）
_json_esc() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

# 验证 ID 安全（只允许字母数字下划线）
_valid_custom_id() {
    case "$1" in
        custom_*) ;;
        *) return 1 ;;
    esac
    case "$1" in
        *[!a-zA-Z0-9_]*) return 1 ;;
    esac
    [ ${#1} -le 64 ]
}

# 列出全部自定义机型（JSON）
cmd_list_custom() {
    if [ -f "$CUSTOM_FILE" ]; then
        cat "$CUSTOM_FILE"
    else
        echo '{"presets":[]}'
    fi
}

# 添加 / 覆盖自定义机型
# 用法: add_custom <id> <label> <brand> <model> <manufacturer> <device> <name> <marketname> <fingerprint>
# 任一字段可以为空字符串，由前端按需传入
cmd_add_custom() {
    local id="$1" label="$2" brand="$3" model="$4"
    local manufacturer="$5" device="$6" name="$7"
    local marketname="$8" fingerprint="$9"

    if [ -z "$id" ]; then
        echo '{"ok":false,"error":"缺少 id"}'; exit 1
    fi
    if ! _valid_custom_id "$id"; then
        echo '{"ok":false,"error":"id 必须以 custom_ 开头，仅允许字母数字下划线"}'; exit 1
    fi
    [ -z "$label" ] && label="$id"
    [ -z "$brand" ] && [ -z "$model" ] && {
        echo '{"ok":false,"error":"brand 和 model 至少要填一个"}'; exit 1
    }

    # 默认 manufacturer = brand
    [ -z "$manufacturer" ] && manufacturer="$brand"
    # 构造 props（只对非空字段写入；按 ro.product.* 的命名）
    local tmp="${CUSTOM_FILE}.tmp.$$"
    : > "$tmp"

    # 收集已有 presets（去掉同 id 的旧条目）
    local existing="[]"
    if [ -f "$CUSTOM_FILE" ]; then
        existing=$(awk -v target_id="$id" '
        BEGIN { out=""; depth=0; cur=""; collecting=0; first=1 }
        {
            line=$0
            i=1
            while (i <= length(line)) {
                ch = substr(line, i, 1)
                if (ch == "{") {
                    if (depth == 0) { cur=""; collecting=1 }
                    depth++
                }
                if (collecting) cur = cur ch
                if (ch == "}") {
                    depth--
                    if (depth == 0 && collecting) {
                        if (index(cur, "\"id\":\"" target_id "\"") == 0 \
                            && index(cur, "\"id\": \"" target_id "\"") == 0) {
                            if (first) { out = out cur; first=0 }
                            else { out = out "," cur }
                        }
                        cur=""; collecting=0
                    }
                }
                i++
            }
        }
        END { print "[" out "]" }
        ' "$CUSTOM_FILE")
    fi

    # 转义所有字段
    local e_label=$(_json_esc "$label")
    local e_brand=$(_json_esc "$brand")
    local e_model=$(_json_esc "$model")
    local e_manufacturer=$(_json_esc "$manufacturer")
    local e_device=$(_json_esc "$device")
    local e_name=$(_json_esc "$name")
    local e_marketname=$(_json_esc "$marketname")
    local e_fingerprint=$(_json_esc "$fingerprint")

    # 构造 props（"ro.product.xxx":"value" 形式，跳过空字段）
    local props=""
    local sep=""
    [ -n "$brand" ]        && { props="${props}${sep}\"ro.product.brand\":\"${e_brand}\""; sep="," ; }
    [ -n "$manufacturer" ] && { props="${props}${sep}\"ro.product.manufacturer\":\"${e_manufacturer}\""; sep="," ; }
    [ -n "$model" ]        && { props="${props}${sep}\"ro.product.model\":\"${e_model}\""; sep="," ; }
    [ -n "$device" ]       && { props="${props}${sep}\"ro.product.device\":\"${e_device}\""; sep="," ; }
    [ -n "$name" ]         && { props="${props}${sep}\"ro.product.name\":\"${e_name}\""; sep="," ; }
    [ -n "$marketname" ]   && { props="${props}${sep}\"ro.product.marketname\":\"${e_marketname}\""; sep="," ; }
    [ -n "$fingerprint" ]  && { props="${props}${sep}\"ro.build.fingerprint\":\"${e_fingerprint}\""; sep="," ; }

    # 新条目
    local new_entry="{\"id\":\"${id}\",\"label\":\"${e_label}\",\"brand\":\"${e_brand}\",\"model\":\"${e_model}\",\"props\":{${props}}}"

    # 合并：existing 是 [...]，去掉外层方括号再拼
    local inner
    inner=$(printf '%s' "$existing" | sed 's/^\[//; s/\]$//')
    if [ -n "$inner" ]; then
        printf '{"presets":[%s,%s]}\n' "$inner" "$new_entry" > "$tmp"
    else
        printf '{"presets":[%s]}\n' "$new_entry" > "$tmp"
    fi
    mv "$tmp" "$CUSTOM_FILE"
    chmod 644 "$CUSTOM_FILE"
    log_json "添加自定义机型: $id ($label)"
    printf '{"ok":true,"id":"%s","label":"%s","msg":"已保存自定义机型"}\n' "$id" "$e_label"
}

# 删除自定义机型
cmd_del_custom() {
    local id="$1"
    [ -z "$id" ] && { echo '{"ok":false,"error":"缺少 id"}'; exit 1; }
    [ ! -f "$CUSTOM_FILE" ] && { echo '{"ok":true,"msg":"不存在"}'; return; }

    local tmp="${CUSTOM_FILE}.tmp.$$"
    local kept
    kept=$(awk -v target_id="$id" '
    BEGIN { out=""; depth=0; cur=""; collecting=0; first=1 }
    {
        line=$0
        i=1
        while (i <= length(line)) {
            ch = substr(line, i, 1)
            if (ch == "{") {
                if (depth == 0) { cur=""; collecting=1 }
                depth++
            }
            if (collecting) cur = cur ch
            if (ch == "}") {
                depth--
                if (depth == 0 && collecting) {
                    if (index(cur, "\"id\":\"" target_id "\"") == 0 \
                        && index(cur, "\"id\": \"" target_id "\"") == 0) {
                        if (first) { out = out cur; first=0 }
                        else { out = out "," cur }
                    }
                    cur=""; collecting=0
                }
            }
            i++
        }
    }
    END { print "[" out "]" }
    ' "$CUSTOM_FILE")

    local inner
    inner=$(printf '%s' "$kept" | sed 's/^\[//; s/\]$//')
    if [ -n "$inner" ]; then
        printf '{"presets":[%s]}\n' "$inner" > "$tmp"
    else
        echo '{"presets":[]}' > "$tmp"
    fi
    mv "$tmp" "$CUSTOM_FILE"

    # 如果当前正在用这个 id，自动恢复
    if [ "$(read_setting current_spoof)" = "$id" ]; then
        cmd_restore >/dev/null 2>&1
    fi

    log_json "删除自定义机型: $id"
    echo '{"ok":true,"msg":"已删除"}'
}

# 从 custom_presets.json 写入指定 id 的 props 到 system.prop
write_prop_from_custom() {
    local id="$1"
    [ ! -f "$CUSTOM_FILE" ] && { log_json "custom 文件不存在"; return 1; }

    > "$PROP_FILE"
    awk -v target="$id" '
    BEGIN { state=0 }
    state==0 {
        line=$0
        if (match(line, /"id"[[:space:]]*:[[:space:]]*"[^"]+"/)) {
            kv = substr(line, RSTART, RLENGTH)
            sub(/^"id"[[:space:]]*:[[:space:]]*"/, "", kv)
            sub(/"$/, "", kv)
            if (kv == target) state = 1
        }
        next
    }
    state==1 {
        if (index($0, "\"props\"") > 0 && index($0, "{") > 0) state = 2
        next
    }
    state==2 {
        line=$0
        # 找到 props 块的右括号 } 或 },
        # 因为我们写入时 props 是单行 JSON，其右括号紧挨着 } 后面
        # 在单行场景下扫描整行的 "key":"value" 序列
        # 同时如果整行就是 "}" 或 "}}" 就退出
        n = split(line, segs, "\"")
        # segs: 1="..." 2=key 3=":\"" 4=value 5="\","..."  (粗略)
        # 用更稳的方式：每次找 "key":"value" 一对
        s = line
        while (match(s, /"[^"]+"[[:space:]]*:[[:space:]]*"[^"]*"/)) {
            piece = substr(s, RSTART, RLENGTH)
            keypart = piece
            sub(/^"/, "", keypart)
            sub(/"[[:space:]]*:[[:space:]]*".*$/, "", keypart)
            valpart = piece
            sub(/^"[^"]+"[[:space:]]*:[[:space:]]*"/, "", valpart)
            sub(/"$/, "", valpart)
            if (keypart != "" && valpart != "") {
                print keypart "=" valpart
            }
            s = substr(s, RSTART + RLENGTH)
        }
        # 单行 props 块 {"a":"1","b":"2"} 写完直接退出
        if (index(line, "}") > 0) exit
    }
    ' "$CUSTOM_FILE" >> "$PROP_FILE"

    chmod 644 "$PROP_FILE"
    local n=$(wc -l < "$PROP_FILE" 2>/dev/null)
    log_json "$id (custom) 写入 $n 条 prop"
    [ "${n:-0}" -ge 1 ]
}

# 从 custom_presets.json 提取 meta（label/brand/model）
extract_custom_meta() {
    local id="$1"
    [ ! -f "$CUSTOM_FILE" ] && return
    awk -v target="$id" '
    BEGIN { state=0; lbl=""; brd=""; mdl="" }
    state==0 {
        if (match($0, /"id"[[:space:]]*:[[:space:]]*"[^"]+"/)) {
            kv = substr($0, RSTART, RLENGTH)
            sub(/^"id"[[:space:]]*:[[:space:]]*"/, "", kv)
            sub(/"$/, "", kv)
            if (kv == target) state = 1
        }
        next
    }
    state==1 {
        if (lbl=="" && match($0, /"label"[[:space:]]*:[[:space:]]*"[^"]*"/)) {
            v=substr($0, RSTART, RLENGTH); sub(/.*"label"[[:space:]]*:[[:space:]]*"/, "", v); sub(/"$/, "", v); lbl=v
        }
        if (brd=="" && match($0, /"brand"[[:space:]]*:[[:space:]]*"[^"]*"/)) {
            v=substr($0, RSTART, RLENGTH); sub(/.*"brand"[[:space:]]*:[[:space:]]*"/, "", v); sub(/"$/, "", v); brd=v
        }
        if (mdl=="" && match($0, /"model"[[:space:]]*:[[:space:]]*"[^"]*"/)) {
            v=substr($0, RSTART, RLENGTH); sub(/.*"model"[[:space:]]*:[[:space:]]*"/, "", v); sub(/"$/, "", v); mdl=v
        }
        if (index($0, "\"props\"") > 0) {
            print lbl "|" brd "|" mdl
            exit
        }
    }
    ' "$CUSTOM_FILE"
}

case "$ACTION" in
    apply)        cmd_apply "$MODEL_ID" ;;
    restore)      cmd_restore ;;
    status)       cmd_status ;;
    current)      cmd_status ;;
    boot_apply)   cmd_boot_apply ;;
    list_custom)  cmd_list_custom ;;
    add_custom)   shift; cmd_add_custom "$@" ;;
    del_custom)   cmd_del_custom "$MODEL_ID" ;;
    *)
        echo '{"ok":false,"error":"unknown action"}'
        exit 1 ;;
esac

