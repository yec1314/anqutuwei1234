#!/system/bin/sh
# 统一路径定义库
# 所有脚本统一 source 本文件以获得目录与文件路径变量
# 仅定义路径与提供 init / clean / migrate 三个函数；不做任何业务

# ============ 模块根 ============
[ -z "$MOD_DIR" ] && MOD_DIR="/data/adb/modules/webui_info"

# ============ 数据根（统一目录）============
WEBUI_ROOT="/data/adb/webui_logs"
WEBUI_CONFIG_DIR="$WEBUI_ROOT/config"
WEBUI_CACHE_DIR="$WEBUI_ROOT/cache"
WEBUI_LOG_DIR="$WEBUI_ROOT/logs"
WEBUI_BACKUP_DIR="$WEBUI_ROOT/backup"
WEBUI_RUNTIME_DIR="$WEBUI_ROOT/runtime"

# ============ 配置文件 ============
WEBUI_SETTINGS="$WEBUI_CONFIG_DIR/settings.conf"
WEBUI_ANTIMARK_CONFIG="$WEBUI_CONFIG_DIR/antimark.json"
WEBUI_PERSIST_CONFIG="$WEBUI_CONFIG_DIR/persist.json"
WEBUI_APP_RULES="$WEBUI_CONFIG_DIR/app_rules.json"
WEBUI_TOUCH_PROFILE="$WEBUI_CONFIG_DIR/touch_profile"
WEBUI_CUSTOM_PRESETS="$WEBUI_CONFIG_DIR/custom_presets.json"

# ============ 缓存文件 ============
WEBUI_PRESETS_CACHE="$WEBUI_CACHE_DIR/presets.json"
WEBUI_APPS_CACHE="$WEBUI_CACHE_DIR/apps.json"

# ============ 备份文件 ============
WEBUI_ANDROID_ID_BACKUP="$WEBUI_BACKUP_DIR/android_id"

# ============ 日志文件 ============
WEBUI_SERVICE_LOG="$WEBUI_LOG_DIR/service.log"
WEBUI_ANDROID_ID_LOG="$WEBUI_LOG_DIR/android_id.log"
WEBUI_APP_HIDE_DAEMON_LOG="$WEBUI_LOG_DIR/app_hide_daemon.log"

# ============ 运行时（开机清空）============
# anti-mark
WEBUI_ANTIMARK_PID="$WEBUI_RUNTIME_DIR/antimark.pid"
WEBUI_ANTIMARK_STATUS="$WEBUI_RUNTIME_DIR/antimark.status"
WEBUI_ANTIMARK_ENABLE="$WEBUI_RUNTIME_DIR/antimark.enable"
WEBUI_ANTIMARK_EMPTY_DIR="$WEBUI_RUNTIME_DIR/antimark_empty"
WEBUI_ANTIMARK_MOUNTS="$WEBUI_RUNTIME_DIR/antimark.mounts"
WEBUI_ANTIMARK_WATCHDOG_PID="$WEBUI_RUNTIME_DIR/antimark_watchdog.pid"
# app_hide
WEBUI_APP_HIDE_DAEMON_PID="$WEBUI_RUNTIME_DIR/app_hide_daemon.pid"
WEBUI_APP_HIDE_WATCHDOG_PID="$WEBUI_RUNTIME_DIR/app_hide_watchdog.pid"
WEBUI_APP_HIDE_APPLIED="$WEBUI_RUNTIME_DIR/app_hide_applied.list"
# monitor / scan / touch / persist-hide
WEBUI_MONITOR_PID="$WEBUI_RUNTIME_DIR/monitor.pid"
WEBUI_SCAN_PROGRESS="$WEBUI_RUNTIME_DIR/scan.progress"
WEBUI_SCAN_LOCK="$WEBUI_RUNTIME_DIR/scan.lock"
WEBUI_TOUCH_DAEMON_PID="$WEBUI_RUNTIME_DIR/touch_daemon.pid"
WEBUI_PERSIST_STATE_DIR="$WEBUI_RUNTIME_DIR/persist_state"
WEBUI_PERSIST_EMPTY_DIR="$WEBUI_PERSIST_STATE_DIR/empty_root"
WEBUI_PERSIST_MOUNT_LIST="$WEBUI_PERSIST_STATE_DIR/mount.list"
WEBUI_PERSIST_MONITOR_PID="$WEBUI_PERSIST_STATE_DIR/monitor.pid"

# ============ 模块内（系统约束，不动）============
WEBUI_SYSTEM_PROP="$MOD_DIR/system.prop"
WEBUI_WEBROOT="$MOD_DIR/webroot"
WEBUI_ICON_DIR="$MOD_DIR/webroot/icons"

# ============ 迁移标记 ============
WEBUI_MIGRATED_FLAG="$WEBUI_ROOT/.migrated_v5"

# ============ 函数 ============
# 初始化所有目录
webui_init_dirs() {
    mkdir -p "$WEBUI_CONFIG_DIR" "$WEBUI_CACHE_DIR" "$WEBUI_LOG_DIR" \
             "$WEBUI_BACKUP_DIR" "$WEBUI_RUNTIME_DIR" 2>/dev/null
    chmod 755 "$WEBUI_ROOT" "$WEBUI_CONFIG_DIR" "$WEBUI_CACHE_DIR" \
              "$WEBUI_LOG_DIR" "$WEBUI_BACKUP_DIR" "$WEBUI_RUNTIME_DIR" 2>/dev/null
}

# 开机清空 runtime（仅清空文件，不删根）
webui_clean_runtime() {
    [ -d "$WEBUI_RUNTIME_DIR" ] || return 0
    # 保留 runtime 根本身，删除内部所有内容
    find "$WEBUI_RUNTIME_DIR" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null
}

# 老路径迁移（仅在首次执行）
webui_migrate_legacy() {
    [ -f "$WEBUI_MIGRATED_FLAG" ] && return 0
    webui_init_dirs

    # ---- 配置 ----
    [ -f "$MOD_DIR/settings.conf" ] && \
        mv -f "$MOD_DIR/settings.conf" "$WEBUI_SETTINGS" 2>/dev/null
    [ -f "/data/adb/webui_antimark_config.json" ] && \
        mv -f "/data/adb/webui_antimark_config.json" "$WEBUI_ANTIMARK_CONFIG" 2>/dev/null
    [ -f "/data/adb/webui_persist_config.json" ] && \
        mv -f "/data/adb/webui_persist_config.json" "$WEBUI_PERSIST_CONFIG" 2>/dev/null
    [ -f "/data/adb/webui_app_rules.json" ] && \
        mv -f "/data/adb/webui_app_rules.json" "$WEBUI_APP_RULES" 2>/dev/null
    [ -f "$MOD_DIR/touch_profile" ] && \
        mv -f "$MOD_DIR/touch_profile" "$WEBUI_TOUCH_PROFILE" 2>/dev/null

    # ---- 缓存 ----
    [ -f "$MOD_DIR/presets-cache.json" ] && \
        mv -f "$MOD_DIR/presets-cache.json" "$WEBUI_PRESETS_CACHE" 2>/dev/null
    [ -f "$MOD_DIR/apps-cache.json" ] && \
        mv -f "$MOD_DIR/apps-cache.json" "$WEBUI_APPS_CACHE" 2>/dev/null

    # ---- 备份 ----
    [ -f "/data/adb/webui_android_id_backup" ] && \
        mv -f "/data/adb/webui_android_id_backup" "$WEBUI_ANDROID_ID_BACKUP" 2>/dev/null

    # ---- 老日志 ----
    [ -f "/data/local/tmp/webui_service.log" ] && \
        mv -f "/data/local/tmp/webui_service.log" "$WEBUI_SERVICE_LOG" 2>/dev/null
    [ -f "/data/local/tmp/webui_android_id.log" ] && \
        mv -f "/data/local/tmp/webui_android_id.log" "$WEBUI_ANDROID_ID_LOG" 2>/dev/null
    [ -f "/data/local/tmp/webui_app_hide_daemon.log" ] && \
        mv -f "/data/local/tmp/webui_app_hide_daemon.log" "$WEBUI_APP_HIDE_DAEMON_LOG" 2>/dev/null

    # ---- /data/local/tmp 残留运行时直接删（重启就重建）----
    rm -rf /data/local/tmp/webui_antimark* 2>/dev/null
    rm -rf /data/local/tmp/webui_app_hide* 2>/dev/null
    rm -rf /data/local/tmp/webui_persist_state 2>/dev/null
    rm -f  /data/local/tmp/webui_monitor.pid 2>/dev/null
    rm -f  /data/local/tmp/webui_scan.lock 2>/dev/null
    rm -f  /data/local/tmp/webui_scan_progress.txt 2>/dev/null
    rm -f  /data/local/tmp/webui_touch_daemon.pid 2>/dev/null

    # 标记已迁移
    : > "$WEBUI_MIGRATED_FLAG"
}
