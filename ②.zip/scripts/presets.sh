#!/system/bin/sh
# 机型预设管理脚本
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
CACHE_FILE="$WEBUI_PRESETS_CACHE"
PRESETS_URL="https://gitee.com/island-style/daoshi/raw/master/presets.json"

# 引入共享 curl 库
. "$MOD_DIR/scripts/lib_curl.sh"
. "$MOD_DIR/scripts/lib_log.sh"
init_log "presets"

ACTION="$1"

log() {
    log_json "$1"
}

cmd_sync() {
    local tmp="/data/local/tmp/presets_dl_$$.json"

    log "开始同步机型库"
    if ! smart_download "$PRESETS_URL" "$tmp"; then
        rm -f "$tmp" "${tmp}.err"
        local DL
        DL=$(pick_downloader)
        if [ -z "$DL" ]; then
            echo '{"ok":false,"error":"未找到可用的 curl 或 wget，请到 其他→网络 中选择"}'
        else
            echo '{"ok":false,"error":"下载失败，请检查网络或到 其他→网络 切换下载器"}'
        fi
        return
    fi

    if ! grep -qE '"presets"|"id"' "$tmp"; then
        rm -f "$tmp" "${tmp}.err"
        echo '{"ok":false,"error":"返回数据格式错误"}'
        return
    fi

    local version=$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[^"]+"' "$tmp" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    local updated=$(grep -oE '"updated"[[:space:]]*:[[:space:]]*"[^"]+"' "$tmp" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    local count=$(grep -oE '"id"[[:space:]]*:' "$tmp" | wc -l)

    mv "$tmp" "$CACHE_FILE"
    chmod 644 "$CACHE_FILE"
    rm -f "${tmp}.err"

    printf '{"ok":true,"msg":"同步成功","version":"%s","updated":"%s","count":%d}\n' \
        "$version" "$updated" "$count"
}

cmd_list() {
    if [ ! -f "$CACHE_FILE" ]; then
        echo '{"ok":false,"need_sync":true}'
        return
    fi

    local tmp_filtered="/data/local/tmp/presets_filt_$$.txt"
    local tmp_output="/data/local/tmp/presets_out_$$.txt"

    grep -nE '"(id|category|label|brand|model|android|props)"[[:space:]]*:' "$CACHE_FILE" > "$tmp_filtered" 2>/dev/null

    awk -F: '
    BEGIN {
        cur_id = ""; cur_cat = ""; cur_label = ""
        cur_brand = ""; cur_model = ""; cur_android = ""
        first = 1
        printf "{\"ok\":true,\"presets\":["
    }

    function emit() {
        if (cur_id != "") {
            if (first) { first = 0 } else { printf "," }
            printf "{\"id\":\"%s\",\"category\":\"%s\",\"label\":\"%s\",\"brand\":\"%s\",\"model\":\"%s\",\"android\":\"%s\"}", \
                cur_id, cur_cat, cur_label, cur_brand, cur_model, cur_android
        }
    }

    function get_value(line) {
        v = line
        sub(/^[0-9]+:/, "", v)
        sub(/^[^:]*:[[:space:]]*"/, "", v)
        sub(/"[[:space:]]*,?[[:space:]]*$/, "", v)
        return v
    }

    /"id"[[:space:]]*:[[:space:]]*"/ {
        emit()
        cur_id = get_value($0)
        cur_cat = ""; cur_label = ""; cur_brand = ""; cur_model = ""; cur_android = ""
        next
    }

    cur_id == "" { next }

    /"category"[[:space:]]*:/ && cur_cat == "" { cur_cat = get_value($0); next }
    /"label"[[:space:]]*:/ && cur_label == "" { cur_label = get_value($0); next }
    /"brand"[[:space:]]*:/ && cur_brand == "" {
        if (index($0, ".brand") == 0) { cur_brand = get_value($0) }
        next
    }
    /"model"[[:space:]]*:/ && cur_model == "" {
        if (index($0, ".model") == 0) { cur_model = get_value($0) }
        next
    }
    /"android"[[:space:]]*:/ && cur_android == "" { cur_android = get_value($0); next }
    /"props"[[:space:]]*:/ { emit(); cur_id = "" }

    END { emit(); printf "]}" }
    ' "$tmp_filtered" > "$tmp_output"

    cat "$tmp_output"
    rm -f "$tmp_filtered" "$tmp_output"
}

cmd_info() {
    if [ ! -f "$CACHE_FILE" ]; then
        echo '{"ok":true,"cached":false,"version":"","updated":"","count":0}'
        return
    fi

    local version=$(grep -oE '"version"[[:space:]]*:[[:space:]]*"[^"]+"' "$CACHE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    local updated=$(grep -oE '"updated"[[:space:]]*:[[:space:]]*"[^"]+"' "$CACHE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
    local count=$(grep -oE '"id"[[:space:]]*:' "$CACHE_FILE" | wc -l)

    printf '{"ok":true,"cached":true,"version":"%s","updated":"%s","count":%d}\n' \
        "$version" "$updated" "$count"
}

case "$ACTION" in
    sync)  cmd_sync ;;
    list)  cmd_list ;;
    info)  cmd_info ;;
    *)
        echo '{"ok":false,"error":"unknown action"}'
        exit 1 ;;
esac
