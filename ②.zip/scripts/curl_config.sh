#!/system/bin/sh
# 下载器配置管理（供前端调用）
# 作者: 呆呆 | QQ:891354018 | 群:774886621
# 用法:
#   sh curl_config.sh list              列出所有 curl 候选 + 当前选择
#   sh curl_config.sh list_wget         列出所有 wget 候选
#   sh curl_config.sh list_all          列出 curl + wget + 当前下载器（统一）
#   sh curl_config.sh test <path>       测试某个 curl/wget 是否能用
#   sh curl_config.sh set_mode <auto|manual>
#   sh curl_config.sh set_path <path>   设置自定义 curl 路径

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
SETTINGS_FILE="$WEBUI_SETTINGS"

. "$MOD_DIR/scripts/lib_curl.sh"

ACTION="$1"

write_setting() {
    local key="$1" val="$2"
    [ ! -f "$SETTINGS_FILE" ] && touch "$SETTINGS_FILE"
    if grep -q "^${key}=" "$SETTINGS_FILE" 2>/dev/null; then
        sed -i "s|^${key}=.*|${key}=${val}|" "$SETTINGS_FILE"
    else
        echo "${key}=${val}" >> "$SETTINGS_FILE"
    fi
}

cmd_list() {
    list_curl_candidates
}

cmd_list_wget() {
    list_wget_candidates
}

# 综合视图：curl + wget + 当前实际选用的下载器
cmd_list_all() {
    local DL kind path mode wget_custom
    DL=$(pick_downloader)
    kind="${DL%%|*}"
    path="${DL#*|}"
    [ -z "$DL" ] && { kind=""; path=""; }
    mode=$(_get_downloader_mode)
    wget_custom=$(_get_setting wget_custom_path)

    printf '{"ok":true,"mode":"%s","wget_custom_path":"%s","current_kind":"%s","current_path":"%s","curl":' \
        "$mode" "$wget_custom" "$kind" "$path"
    list_curl_candidates
    printf ',"wget":'
    list_wget_candidates
    printf '}'
}

cmd_test() {
    local path="$2"
    [ -z "$path" ] && { echo '{"ok":false,"error":"path required"}'; exit 1; }

    if [ ! -e "$path" ] && [ "$path" != "curl" ] && [ "$path" != "wget" ]; then
        printf '{"ok":false,"path":"%s","exists":false,"error":"文件不存在"}\n' "$path"
        return
    fi

    # 优先按 curl 试，再按 wget 试
    if test_curl_works "$path"; then
        local ver
        ver=$("$path" --version 2>/dev/null | head -1 | tr -d '"\\')
        printf '{"ok":true,"path":"%s","kind":"curl","works":true,"version":"%s"}\n' "$path" "$ver"
        return
    fi
    if test_wget_works "$path"; then
        local ver kind="wget"
        case "$path" in
            */busybox|*/toybox) kind="wget_bb" ;;
        esac
        ver=$("$path" --help 2>&1 | head -1 | tr -d '"\\' | head -c 80)
        printf '{"ok":true,"path":"%s","kind":"%s","works":true,"version":"%s"}\n' "$path" "$kind" "$ver"
        return
    fi

    local out
    out=$("$path" --version 2>&1 | head -1 | tr -d '"\\' | head -c 200)
    printf '{"ok":true,"path":"%s","works":false,"version":"%s"}\n' "$path" "$out"
}

cmd_set_mode() {
    local mode="$2"
    case "$mode" in
        auto|curl|wget)
            write_setting "downloader_mode" "$mode"
            # 同步老 key（向后兼容）
            case "$mode" in
                auto) write_setting "curl_mode" "auto" ;;
                curl) write_setting "curl_mode" "manual" ;;
            esac
            printf '{"ok":true,"mode":"%s"}\n' "$mode"
            ;;
        manual)
            # 老接口兼容：等价于 curl
            write_setting "downloader_mode" "curl"
            write_setting "curl_mode" "manual"
            printf '{"ok":true,"mode":"curl"}\n'
            ;;
        *)
            echo '{"ok":false,"error":"mode must be auto|curl|wget"}'
            exit 1
            ;;
    esac
}

cmd_set_path() {
    local path="$2"
    [ -z "$path" ] && { echo '{"ok":false,"error":"path required"}'; exit 1; }

    if ! test_curl_works "$path"; then
        local out
        out=$("$path" --version 2>&1 | head -1 | tr -d '"\\' | head -c 200)
        printf '{"ok":false,"error":"该路径的 curl 无法运行：%s"}\n' "$out"
        exit 1
    fi

    write_setting "curl_custom_path" "$path"
    write_setting "downloader_mode" "curl"
    write_setting "curl_mode" "manual"
    printf '{"ok":true,"path":"%s","msg":"已设置并切换到 curl 手动模式"}\n' "$path"
}

cmd_set_wget() {
    local path="$2"
    [ -z "$path" ] && { echo '{"ok":false,"error":"path required"}'; exit 1; }

    if ! test_wget_works "$path"; then
        local out
        out=$("$path" --help 2>&1 | head -1 | tr -d '"\\' | head -c 200)
        printf '{"ok":false,"error":"该路径的 wget 无法运行：%s"}\n' "$out"
        exit 1
    fi

    write_setting "wget_custom_path" "$path"
    write_setting "downloader_mode" "wget"
    printf '{"ok":true,"path":"%s","msg":"已设置并切换到 wget 手动模式"}\n' "$path"
}

case "$ACTION" in
    list)       cmd_list ;;
    list_wget)  cmd_list_wget ;;
    list_all)   cmd_list_all ;;
    test)       cmd_test "$@" ;;
    set_mode)   cmd_set_mode "$@" ;;
    set_path)   cmd_set_path "$@" ;;
    set_wget)   cmd_set_wget "$@" ;;
    *)
        echo '{"ok":false,"error":"unknown action - use: list | list_wget | list_all | test <path> | set_mode <auto|curl|wget> | set_path <path> | set_wget <path>"}'
        exit 1
        ;;
esac
