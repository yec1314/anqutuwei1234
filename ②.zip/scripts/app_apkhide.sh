#!/system/bin/sh
# 应用隐藏管理（APK备份版）
# 原理：完全照搬「应用隐藏..sh」的做法
#   隐藏: pm path 获取APK → cp 备份 → pm uninstall -k --user 0
#   恢复: 从备份 pm install（支持 split APK 的 session install）→ pm enable
# 不做 tar 数据备份（pm uninstall -k 已保留 /data/data，tar 会卡死且恢复后闪退）
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
. "$MOD_DIR/scripts/lib_log.sh"
init_log "app_apkhide"

# ============ 默认路径 ============
CONFIG_FILE="$WEBUI_CONFIG_DIR/apkhide.conf"
DEFAULT_APK_DIR="$WEBUI_ROOT/apk_backup"

# 读取配置
load_config() {
    APK_DIR="$DEFAULT_APK_DIR"
    if [ -f "$CONFIG_FILE" ]; then
        local v
        v=$(grep "^apk_dir=" "$CONFIG_FILE" 2>/dev/null | cut -d= -f2-)
        [ -n "$v" ] && APK_DIR="$v"
    fi
}

# 保存配置
save_config() {
    mkdir -p "$(dirname "$CONFIG_FILE")" 2>/dev/null
    echo "apk_dir=$APK_DIR" > "$CONFIG_FILE"
}

# ============ 隐藏应用 ============
# 完全参考「应用隐藏..sh」的 hide_one 逻辑
cmd_hide() {
    local pkg="$1"
    if [ -z "$pkg" ]; then
        echo '{"ok":false,"error":"缺少包名"}'
        return
    fi

    load_config
    mkdir -p "$APK_DIR" 2>/dev/null

    # 检查应用是否存在（已安装且可见）
    if ! pm list packages 2>/dev/null | grep -q "^package:${pkg}$"; then
        echo '{"ok":false,"error":"应用不存在或已隐藏"}'
        return
    fi

    # 获取所有 APK 路径（支持 split APK）
    local paths
    paths=$(pm path "$pkg" 2>/dev/null | sed 's/package://')
    if [ -z "$paths" ]; then
        echo '{"ok":false,"error":"找不到APK路径"}'
        return
    fi

    # 备份 APK 文件
    rm -rf "$APK_DIR/$pkg"
    mkdir -p "$APK_DIR/$pkg"
    local count=0
    for p in $paths; do
        [ -f "$p" ] || continue
        cp "$p" "$APK_DIR/$pkg/$(basename "$p")"
        count=$((count + 1))
    done

    if [ "$count" -eq 0 ]; then
        rm -rf "$APK_DIR/$pkg"
        echo '{"ok":false,"error":"APK备份失败，无法复制文件"}'
        return
    fi

    # 执行卸载（-k 保留数据）
    local result
    result=$(pm uninstall -k --user 0 "$pkg" 2>&1)

    # 验证是否真的隐藏了
    if pm list packages 2>/dev/null | grep -q "^package:${pkg}$"; then
        # 还在，卸载没生效
        rm -rf "$APK_DIR/$pkg"
        printf '{"ok":false,"error":"卸载命令未生效: %s"}\n' "$(echo "$result" | tr '"' "'" | tr '\n' ' ')"
        return
    fi

    log_json "隐藏应用: $pkg (APK $count 个)"
    printf '{"ok":true,"msg":"已隐藏 %s","apk_count":%d}\n' "$pkg" "$count"
}

# ============ 恢复应用 ============
# 完全参考「应用隐藏..sh」的 show_one 逻辑
cmd_show() {
    local pkg="$1"
    if [ -z "$pkg" ]; then
        echo '{"ok":false,"error":"缺少包名"}'
        return
    fi

    load_config

    # 已经显示了就跳过
    if pm list packages 2>/dev/null | grep -q "^package:${pkg}$"; then
        echo '{"ok":true,"msg":"应用已显示，无需恢复"}'
        return
    fi

    # 检查备份是否存在
    if [ ! -d "$APK_DIR/$pkg" ]; then
        echo '{"ok":false,"error":"无APK备份，无法恢复"}'
        return
    fi

    # 准备临时目录
    local tmp_dir="/data/local/tmp/apk_restore_$$"
    rm -rf "$tmp_dir"
    mkdir -p "$tmp_dir"

    local apk_count=0
    for a in "$APK_DIR/$pkg"/*.apk; do
        [ -f "$a" ] || continue
        cp "$a" "$tmp_dir/"
        apk_count=$((apk_count + 1))
    done

    if [ "$apk_count" -eq 0 ]; then
        rm -rf "$tmp_dir"
        echo '{"ok":false,"error":"备份目录中无APK文件"}'
        return
    fi

    chmod 644 "$tmp_dir"/*.apk 2>/dev/null

    # 安装（照搬原始脚本逻辑）
    local install_ok=false
    if [ "$apk_count" -eq 1 ]; then
        # 单 APK 直接安装
        local apk_file
        apk_file=$(ls "$tmp_dir"/*.apk 2>/dev/null | head -1)
        local res
        res=$(pm install -r -d --user 0 "$apk_file" 2>&1)
        echo "$res" | grep -qi "success" && install_ok=true
    else
        # 多 APK: session install（split APK）
        local total_size=0
        for a in "$tmp_dir"/*.apk; do
            local sz
            sz=$(stat -c%s "$a" 2>/dev/null || wc -c < "$a")
            total_size=$((total_size + sz))
        done

        local sid
        sid=$(pm install-create --user 0 -r -d -S "$total_size" 2>/dev/null | grep -oE '[0-9]+' | head -1)
        if [ -n "$sid" ]; then
            local idx=0
            for a in "$tmp_dir"/*.apk; do
                local sz
                sz=$(stat -c%s "$a" 2>/dev/null || wc -c < "$a")
                pm install-write -S "$sz" "$sid" "split$idx" "$a" >/dev/null 2>&1
                idx=$((idx + 1))
            done
            local commit_res
            commit_res=$(pm install-commit "$sid" 2>&1)
            echo "$commit_res" | grep -qi "success" && install_ok=true
        fi
    fi

    # 启用应用
    pm enable "$pkg" >/dev/null 2>&1

    # 清理临时目录
    rm -rf "$tmp_dir"

    if [ "$install_ok" = "true" ]; then
        # 安装成功，删除备份
        rm -rf "$APK_DIR/$pkg"
        log_json "恢复应用: $pkg"
        printf '{"ok":true,"msg":"已恢复 %s"}\n' "$pkg"
    else
        printf '{"ok":false,"error":"安装失败，备份保留在 %s/%s"}\n' "$APK_DIR" "$pkg"
    fi
}

# ============ 恢复所有 ============
cmd_show_all() {
    load_config
    mkdir -p "$APK_DIR" 2>/dev/null

    local count=0 fail=0
    for dir in "$APK_DIR"/*/; do
        [ -d "$dir" ] || continue
        local pkg
        pkg=$(basename "$dir")
        [ -z "$pkg" ] || [ "$pkg" = "*" ] && continue

        if pm list packages 2>/dev/null | grep -q "^package:${pkg}$"; then
            continue
        fi

        local res
        res=$(cmd_show "$pkg")
        if echo "$res" | grep -q '"ok":true'; then
            count=$((count + 1))
        else
            fail=$((fail + 1))
        fi
    done

    log_json "批量恢复: 成功 $count, 失败 $fail"
    printf '{"ok":true,"msg":"恢复完成","success":%d,"fail":%d}\n' "$count" "$fail"
}

# ============ 列出已隐藏 ============
cmd_list() {
    load_config
    mkdir -p "$APK_DIR" 2>/dev/null

    local json="" sep="" count=0
    for dir in "$APK_DIR"/*/; do
        [ -d "$dir" ] || continue
        local pkg
        pkg=$(basename "$dir")
        [ -z "$pkg" ] || [ "$pkg" = "*" ] && continue

        local apk_count=0 total_size=0
        for a in "$dir"/*.apk; do
            [ -f "$a" ] || continue
            apk_count=$((apk_count + 1))
            local sz
            sz=$(stat -c%s "$a" 2>/dev/null || echo 0)
            total_size=$((total_size + sz))
        done

        json="${json}${sep}{\"pkg\":\"${pkg}\",\"apk_count\":${apk_count},\"size\":${total_size}}"
        sep=","
        count=$((count + 1))
    done

    printf '{"ok":true,"count":%d,"hidden":[%s]}\n' "$count" "$json"
}

# ============ 获取配置 ============
cmd_get_config() {
    load_config
    printf '{"ok":true,"apk_dir":"%s","default_apk_dir":"%s"}\n' "$APK_DIR" "$DEFAULT_APK_DIR"
}

# ============ 设置APK目录 ============
cmd_set_apk_dir() {
    local path="$1"
    if [ -z "$path" ]; then
        echo '{"ok":false,"error":"缺少路径"}'
        return
    fi
    mkdir -p "$path" 2>/dev/null
    if [ ! -d "$path" ]; then
        echo '{"ok":false,"error":"目录创建失败，请检查路径权限"}'
        return
    fi
    load_config
    APK_DIR="$path"
    save_config
    log_json "设置APK备份目录: $path"
    printf '{"ok":true,"msg":"备份目录已设置为 %s"}\n' "$path"
}

# ============ 获取状态 ============
cmd_status() {
    load_config
    mkdir -p "$APK_DIR" 2>/dev/null

    local hidden_count=0
    for dir in "$APK_DIR"/*/; do
        [ -d "$dir" ] || continue
        local pkg
        pkg=$(basename "$dir")
        [ -z "$pkg" ] || [ "$pkg" = "*" ] && continue
        hidden_count=$((hidden_count + 1))
    done

    printf '{"ok":true,"hidden_count":%d,"apk_dir":"%s"}\n' "$hidden_count" "$APK_DIR"
}

# ============ 入口 ============
ACTION="$1"
ARG2="$2"

case "$ACTION" in
    status)       cmd_status ;;
    list)         cmd_list ;;
    hide)         cmd_hide "$ARG2" ;;
    show)         cmd_show "$ARG2" ;;
    show_all)     cmd_show_all ;;
    get_config)   cmd_get_config ;;
    set_apk_dir)  cmd_set_apk_dir "$ARG2" ;;
    *)
        echo '{"ok":false,"error":"unknown action: '"$ACTION"'"}'
        ;;
esac
