#!/system/bin/sh
# 防标记看护 - boot 上下文常驻，检测守护死亡后重新拉起
MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
. "$MOD_DIR/scripts/lib_log.sh"
init_log "antimark"

ANTIMARK="$MOD_DIR/scripts/anti-mark.sh"
PID_FILE="$WEBUI_ANTIMARK_PID"
ENABLE_FILE="$WEBUI_ANTIMARK_ENABLE"
WATCHDOG_PID_FILE="$WEBUI_ANTIMARK_WATCHDOG_PID"
CHECK_INTERVAL=1

echo "$$" > "$WATCHDOG_PID_FILE"

read_enable() {
    cat "$ENABLE_FILE" 2>/dev/null | tr -d ' \n\r'
}

while true; do
    if [ "$(read_enable)" = "1" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null | tr -d ' \n\r')
        if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
            log_json "看护检测到防标记守护已死，重新拉起"
            sh "$ANTIMARK" start >/dev/null 2>&1
        fi
    fi
    sleep "$CHECK_INTERVAL"
done