#!/system/bin/sh
# 模块/脚本市场数据获取脚本
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
MARKET_URL="https://gitee.com/island-style/daoshi/raw/master/market.json"
ACTION="$1"

# 引入共享 curl 库
. "$MOD_DIR/scripts/lib_curl.sh"
. "$MOD_DIR/scripts/lib_log.sh"
init_log "market"

log() {
    log_json "$1"
}

cmd_fetch() {
    local tmp="/data/local/tmp/market_dl_$$.json"
    local err_log="${tmp}.err"

    log "拉取市场数据"
    if ! smart_download "$MARKET_URL" "$tmp"; then
        local err_msg=""
        [ -s "$err_log" ] && err_msg=$(head -c 200 "$err_log" | tr -d '"\\')
        rm -f "$tmp" "$err_log"
        log "下载失败: $err_msg"

        case "$err_msg" in
            *"CANNOT LINK"*|*"cannot locate"*)
                err_msg="curl 不兼容，请到设置中切换下载器" ;;
            *"Could not resolve"*|*"resolve host"*)
                err_msg="DNS 解析失败，请切换网络或 DNS" ;;
            *"timeout"*|*"timed out"*)
                err_msg="连接超时，请检查网络" ;;
            *"refused"*)
                err_msg="连接被拒绝，可能被防火墙拦截" ;;
        esac

        local DL
        DL=$(pick_downloader)
        if [ -z "$DL" ]; then
            err_msg="未找到可用的 curl 或 wget"
        fi
        printf '{"ok":false,"error":"下载失败：%s"}\n' "${err_msg:-请检查网络或市场链接}"
        return
    fi

    if ! grep -q "{" "$tmp"; then
        local preview=$(head -c 120 "$tmp" | tr -d '"\\\n\r')
        rm -f "$tmp" "$err_log"
        log "返回非 JSON: $preview"
        printf '{"ok":false,"error":"返回数据非 JSON：%s"}\n' "$preview"
        return
    fi

    tr -d '\r\n' < "$tmp"
    rm -f "$tmp" "$err_log"
    log "成功"
}

case "$ACTION" in
    fetch) cmd_fetch ;;
    *)
        echo '{"ok":false,"error":"unknown action - use: fetch"}'
        exit 1 ;;
esac
