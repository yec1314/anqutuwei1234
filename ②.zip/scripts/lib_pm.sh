#!/system/bin/sh
# 应用隐藏 / 解除隐藏的多兼容性封装
# 不同 ROM / Android 版本对 pm 子命令的支持不同，
# 这里把 disable-user / hide / suspend 三种机制都尝试一遍，并对所有活跃用户执行
# 作者: 呆呆 | QQ:891354018 | 群:774886621

# 列出所有活跃用户 ID（默认至少 0）
list_user_ids() {
    local ids
    ids=$(pm list users 2>/dev/null | grep -oE 'UserInfo\{[0-9]+' | grep -oE '[0-9]+' | sort -u)
    [ -z "$ids" ] && ids=$(cmd package list users 2>/dev/null | grep -oE 'UserInfo\{[0-9]+' | grep -oE '[0-9]+' | sort -u)
    [ -z "$ids" ] && ids="0"
    echo "$ids"
}

# 静默执行命令，成功时返回 0
_pm_try() {
    "$@" >/dev/null 2>&1
}

# 隐藏单个应用，对所有用户尝试 disable-user / hide / suspend / cmd package 兜底
# 任一命令成功即视为已生效
# 用法: hide_app <pkg>
hide_app() {
    local pkg="$1"
    [ -z "$pkg" ] && return 1

    local users any=0 u
    users=$(list_user_ids)
    for u in $users; do
        _pm_try pm disable-user --user "$u" "$pkg" && any=1
        _pm_try pm hide --user "$u" "$pkg" && any=1
        _pm_try pm suspend --user "$u" "$pkg" && any=1
        _pm_try cmd package disable-user --user "$u" "$pkg" && any=1
        _pm_try cmd package hide --user "$u" "$pkg" && any=1
        _pm_try cmd package suspend --user "$u" "$pkg" && any=1
    done

    # 没有 --user 参数的旧版兜底
    if [ "$any" = "0" ]; then
        _pm_try pm disable "$pkg" && any=1
        _pm_try pm hide "$pkg" && any=1
    fi

    [ "$any" = "1" ]
}

# 解除隐藏 / 解除冻结
# 用法: unhide_app <pkg>
unhide_app() {
    local pkg="$1"
    [ -z "$pkg" ] && return 1

    local users u
    users=$(list_user_ids)
    for u in $users; do
        _pm_try pm enable --user "$u" "$pkg"
        _pm_try pm unhide --user "$u" "$pkg"
        _pm_try pm unsuspend --user "$u" "$pkg"
        _pm_try cmd package enable --user "$u" "$pkg"
        _pm_try cmd package unhide --user "$u" "$pkg"
        _pm_try cmd package unsuspend --user "$u" "$pkg"
    done
    _pm_try pm enable "$pkg"
    _pm_try pm unhide "$pkg"

    return 0
}

# 检查 pkg 是否被隐藏（任一用户被禁/隐藏即返回 0）
is_hidden() {
    local pkg="$1"
    [ -z "$pkg" ] && return 1
    local users u
    users=$(list_user_ids)
    for u in $users; do
        if pm list packages -d --user "$u" 2>/dev/null | grep -q "^package:${pkg}$"; then
            return 0
        fi
        if pm list packages --user "$u" 2>/dev/null | grep -q "^package:${pkg}$"; then
            local s
            s=$(dumpsys package "$pkg" 2>/dev/null | grep -E "hidden=true|suspended=true" | head -1)
            [ -n "$s" ] && return 0
        fi
    done
    return 1
}
