#!/system/bin/sh
# 应用控制看护 - boot 上下文常驻，检测守护进程死亡后重新拉起
MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
. "$MOD_DIR/scripts/lib_log.sh"
init_log "app_hide"

SETTINGS_FILE="$WEBUI_SETTINGS"
PID_FILE="$WEBUI_APP_HIDE_DAEMON_PID"
WATCHDOG_PID_FILE="$WEBUI_APP_HIDE_WATCHDOG_PID"
CHECK_INTERVAL=1

echo "$$" > "$WATCHDOG_PID_FILE"

read_enabled() {
    grep "^app_hide_daemon_enabled=" "$SETTINGS_FILE" 2>/dev/null \
        | cut -d= -f2 | tr -d ' \n\r'
}

while true; do
    if [ "$(read_enabled)" = "1" ]; then
        pid=$(cat "$PID_FILE" 2>/dev/null | tr -d ' \n\r')
        if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
            log_json "看护检测到守护已死，重新拉起"
            sh "$MOD_DIR/scripts/app_hide.sh" daemon_start >/dev/null 2>&1
        fi
    fi
    sleep "$CHECK_INTERVAL"
done