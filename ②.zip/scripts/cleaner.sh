#!/system/bin/sh
# 缓存清理脚本 - 多游戏支持
# 作者: 呆呆 | QQ:891354018 | 群:774886621
# 用法:
#   sh cleaner.sh                    无畏契约深度清理（默认）
#   sh cleaner.sh deep               无畏契约深度清理
#   sh cleaner.sh light              无畏契约轻度清理
#   sh cleaner.sh inotify            仅优化 inotify 参数（静默）
#   sh cleaner.sh pubgmhd_light      和平精英轻度清理
#   sh cleaner.sh pubgmhd_deep       和平精英深度清理
#   sh cleaner.sh sgame_deep         王者荣耀清理
#   sh cleaner.sh cf_deep            穿越火线手游清理
#   sh cleaner.sh delta_cn_deep      三角洲行动·国服清理
#   sh cleaner.sh delta_tw_deep      三角洲行动·台服清理
#   sh cleaner.sh delta_global_deep  三角洲行动·国际服清理
#   sh cleaner.sh arena_cn_deep      暗区突围·国服清理
#   sh cleaner.sh arena_global_deep  暗区突围·国际服清理
#   sh cleaner.sh arena_tw_deep      暗区突围·台服清理
#   sh cleaner.sh arena_vn_deep      暗区突围·越南服清理
#   sh cleaner.sh cod_deep           使命召唤手游清理

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
SETTINGS_FILE="$WEBUI_SETTINGS"
ARG1="$1"

. "$MOD_DIR/scripts/lib_log.sh"
init_log "cleaner"

log() {
    log_json "$1"
}

write_setting() {
    local key="$1"
    local val="$2"
    [ ! -f "$SETTINGS_FILE" ] && touch "$SETTINGS_FILE"
    if grep -q "^${key}=" "$SETTINGS_FILE" 2>/dev/null; then
        sed -i "s|^${key}=.*|${key}=${val}|" "$SETTINGS_FILE"
    else
        echo "${key}=${val}" >> "$SETTINGS_FILE"
    fi
}

PKG="com.tencent.tmgp.codev"
EXT_DIR="/storage/emulated/0/Android/data/$PKG"
INT_DIR="/data/user/0/$PKG"

PUBG_PKG="com.tencent.tmgp.pubgmhd"
PUBG_INT_DIR="/data/user/0/$PUBG_PKG"
PUBG_FILES_DIR="$PUBG_INT_DIR/files"
PUBG_EXT_DIR="/storage/emulated/0/Android/data/$PUBG_PKG"

is_pkg_installed() {
    local pkg="$1"
    pm path "$pkg" >/dev/null 2>&1 && return 0
    cmd package path "$pkg" >/dev/null 2>&1 && return 0
    [ -d "/data/data/$pkg" ] && return 0
    [ -d "/data/user/0/$pkg" ] && return 0
    [ -d "/storage/emulated/0/Android/data/$pkg" ] && return 0
    return 1
}

optimize_inotify() {
    echo 16384 > /proc/sys/fs/inotify/max_queued_events 2>/dev/null
    echo 128 > /proc/sys/fs/inotify/max_user_instances 2>/dev/null
    echo 8192 > /proc/sys/fs/inotify/max_user_watches 2>/dev/null
}

clean_light() {
    rm -rf /data/user/*/"$PKG/files/ano_tmp" 2>/dev/null
    rm -rf "$INT_DIR/cache" "$INT_DIR/code_cache" 2>/dev/null
    return 0
}

clean_deep() {
    optimize_inotify
    rm -rf /data/user/*/"$PKG/files/ano_tmp" 2>/dev/null

    if [ ! -d "$EXT_DIR" ] && [ ! -d "$INT_DIR" ]; then
        return 1
    fi

    [ -d "$EXT_DIR" ] && find "$EXT_DIR" -mindepth 1 -maxdepth 1 ! -name files -exec rm -r {} + 2>/dev/null

    [ -d "$EXT_DIR/files" ] && find "$EXT_DIR/files/" -mindepth 1 -maxdepth 1 \
        ! \( -name EstvShadowPlugin_shadow-app -o -name VulkanProgramBinaryCache -o -name UE4Game \) \
        -exec rm -r {} + 2>/dev/null

    if [ -d "$EXT_DIR/files/UE4Game/CodeV" ]; then
        find "$EXT_DIR/files/UE4Game/CodeV/" -maxdepth 1 -type f 2>/dev/null | while read f; do
            fn=$(basename "$f")
            case "$fn" in
                Manifest_UFSFiles_Android.txt|NotAllowedUnattendedBugReports|Version.cfg|ClearFlag_*|BagSkinCache_*.json|PlayerData.cfg|PCache.meta|Manifest.ini)
                    continue ;;
                *)
                    rm -f "$f" ;;
            esac
        done
    fi

    SAVED="$EXT_DIR/files/UE4Game/CodeV/CodeV/Saved"
    if [ -d "$SAVED" ]; then
        rm -rf "$SAVED/Gamelet/logs" "$SAVED/Gamelet/cookies" 2>/dev/null
        find "$SAVED/" -mindepth 1 -maxdepth 1 \
            ! \( -name ClearFlag_* -o -name ImageDownload -o -name Gamelet -o -name ShaderCache -o -name Paks -o -name MMKV -o -name Version.cfg -o -name PlayerData.cfg -o -name PCache.meta \) \
            -exec rm -r {} + 2>/dev/null
    fi

    rm -rf "$INT_DIR/cache" "$INT_DIR/code_cache" 2>/dev/null

    [ -d "$INT_DIR/files" ] && find "$INT_DIR/files/" -mindepth 1 -maxdepth 1 \
        ! \( -name ves -o -name live -o -name EstvShadowDir -o -name estv-valm-RELEASE \) \
        -exec rm -r {} + 2>/dev/null

    [ -d "$INT_DIR" ] && find "$INT_DIR/" -mindepth 1 -maxdepth 1 \
        ! \( -name app_tbs_64 -o -name files \) -exec rm -r {} + 2>/dev/null

    return 0
}

clean_pubgmhd_light() {
    if ! is_pkg_installed "$PUBG_PKG"; then
        return 1
    fi
    rm -rf "$PUBG_INT_DIR/cache" "$PUBG_INT_DIR/code_cache" 2>/dev/null
    [ -d "$PUBG_EXT_DIR/cache" ] && rm -rf "$PUBG_EXT_DIR/cache" 2>/dev/null
    return 0
}

clean_pubgmhd_deep() {
    if ! is_pkg_installed "$PUBG_PKG"; then
        return 1
    fi
    # data/user/*/PKG/* 保留 files
    for d in /data/user/*/"$PUBG_PKG"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 ! -name files -exec rm -r {} + 2>/dev/null
    done
    # data/user/*/PKG/files/* 保留 ProgramBinaryCache
    for d in /data/user/*/"$PUBG_PKG/files"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 ! -name ProgramBinaryCache -exec rm -r {} + 2>/dev/null
    done
    # storage/emulated/*/Android/data/PKG/* 保留 files
    for d in /storage/emulated/*/Android/data/"$PUBG_PKG"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 ! -name files -exec rm -r {} + 2>/dev/null
    done
    # storage/emulated/*/Android/data/PKG/files/* 保留 UE4Game
    for d in /storage/emulated/*/Android/data/"$PUBG_PKG/files"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 ! -name UE4Game -exec rm -r {} + 2>/dev/null
    done
    # storage/emulated/*/Android/data/PKG/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/* 保留 Paks
    for d in /storage/emulated/*/Android/data/"$PUBG_PKG"/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 ! -name Paks -exec rm -r {} + 2>/dev/null
    done
    return 0
}

# ========== 通用清理辅助函数（新版多游戏支持） ==========
# 用法：clean_under_top_except <pkg> [保留项...]
#   清理 /data/user/*/PKG/* 下的所有顶层条目，可指定保留若干名字
clean_under_top_except() {
    local pkg="$1"; shift
    local keep_args=""
    for k in "$@"; do
        keep_args="$keep_args ! -name $k"
    done
    for d in /data/user/*/"$pkg"; do
        [ -d "$d" ] || continue
        eval "find \"$d/\" -mindepth 1 -maxdepth 1 $keep_args -exec rm -r {} + 2>/dev/null"
    done
}

# 用法：clean_under_top_all <pkg>
clean_under_top_all() {
    local pkg="$1"
    for d in /data/user/*/"$pkg"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 -exec rm -r {} + 2>/dev/null
    done
}

# 用法：clean_under_files_except <pkg> [保留项...]
clean_under_files_except() {
    local pkg="$1"; shift
    local keep_args=""
    for k in "$@"; do
        keep_args="$keep_args ! -name $k"
    done
    for d in /data/user/*/"$pkg/files"; do
        [ -d "$d" ] || continue
        eval "find \"$d/\" -mindepth 1 -maxdepth 1 $keep_args -exec rm -r {} + 2>/dev/null"
    done
}

# 用法：clean_under_files_all <pkg>  强制清空 files
clean_under_files_all() {
    local pkg="$1"
    for d in /data/user/*/"$pkg/files"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 -exec rm -r {} + 2>/dev/null
    done
}

# 用法：clean_storage_all <pkg>  清空外部存储目录所有内容
clean_storage_all_for() {
    local pkg="$1"
    for d in /storage/emulated/*/Android/data/"$pkg"; do
        [ -d "$d" ] || continue
        find "$d/" -mindepth 1 -maxdepth 1 -exec rm -r {} + 2>/dev/null
    done
}

# 用法：clean_storage_top_except <pkg> [保留项...]
clean_storage_top_except_for() {
    local pkg="$1"; shift
    local keep_args=""
    for k in "$@"; do
        keep_args="$keep_args ! -name $k"
    done
    for d in /storage/emulated/*/Android/data/"$pkg"; do
        [ -d "$d" ] || continue
        eval "find \"$d/\" -mindepth 1 -maxdepth 1 $keep_args -exec rm -r {} + 2>/dev/null"
    done
}

# 用法：clean_storage_files_except <pkg> [保留项...]
clean_storage_files_except_for() {
    local pkg="$1"; shift
    local keep_args=""
    for k in "$@"; do
        keep_args="$keep_args ! -name $k"
    done
    for d in /storage/emulated/*/Android/data/"$pkg/files"; do
        [ -d "$d" ] || continue
        eval "find \"$d/\" -mindepth 1 -maxdepth 1 $keep_args -exec rm -r {} + 2>/dev/null"
    done
}

# ========== 王者荣耀 ==========
SGAME_PKG="com.tencent.tmgp.sgame"
clean_sgame_deep() {
    is_pkg_installed "$SGAME_PKG" || return 1
    clean_under_top_except    "$SGAME_PKG" files
    clean_under_files_except  "$SGAME_PKG" QtsVFSCache TP
    clean_storage_all_for     "$SGAME_PKG"
    return 0
}

# ========== 穿越火线手游 ==========
CF_PKG="com.tencent.tmgp.cf"
clean_cf_deep() {
    is_pkg_installed "$CF_PKG" || return 1
    clean_under_top_except         "$CF_PKG" shared_prefs
    clean_storage_top_except_for   "$CF_PKG" files
    clean_storage_files_except_for "$CF_PKG" Assets4
    return 0
}

# ========== 三角洲行动（三服通用） ==========
clean_delta_for() {
    local pkg="$1"
    is_pkg_installed "$pkg" || return 1
    clean_under_top_except    "$pkg" files
    clean_under_files_except  "$pkg" UE4Game
    # 删除 Manifest_UFSFiles_Android.txt（强制重新校验）
    for manifest in /data/user/*/"$pkg"/files/UE4Game/DeltaForce/Manifest_UFSFiles_Android.txt; do
        [ -f "$manifest" ] && rm -f "$manifest" 2>/dev/null
    done
    clean_storage_all_for "$pkg"
    return 0
}

# ========== 暗区突围（四服通用） ==========
clean_arena_for() {
    local pkg="$1"
    is_pkg_installed "$pkg" || return 1
    clean_under_top_except       "$pkg" files
    clean_under_files_all        "$pkg"
    clean_storage_top_except_for "$pkg" files
    return 0
}

# ========== 使命召唤手游 ==========
COD_PKG="com.tencent.tmgp.cod"
clean_cod_deep() {
    is_pkg_installed "$COD_PKG" || return 1
    clean_under_top_all            "$COD_PKG"
    clean_storage_top_except_for   "$COD_PKG" files
    clean_storage_files_except_for "$COD_PKG" Config ExtractQts PufferQts
    return 0
}

# ========== 通用 JSON 输出包装（新游戏共用） ==========
# 用法：run_simple <清理函数名> <展示名> <未安装提示>
run_simple() {
    local fn="$1"
    local label="$2"
    local notfound="$3"
    $fn
    local ret=$?
    if [ $ret -eq 0 ]; then
        NOW="$(date '+%Y-%m-%d %H:%M:%S')"
        log "$label 完成"
        printf '{"ok":true,"msg":"%s完成","time":"%s"}\n' "$label" "$NOW"
    else
        log "$label 失败：$notfound 未安装"
        printf '{"ok":false,"error":"%s未安装"}\n' "$notfound"
    fi
}

run_and_report() {
    local mode="$1"
    local label
    if [ "$mode" = "light" ]; then
        clean_light
        RET=$?
        label="轻度清理"
    else
        clean_deep
        RET=$?
        label="深度清理"
    fi

    if [ $RET -eq 0 ]; then
        NOW="$(date '+%Y-%m-%d %H:%M:%S')"
        write_setting "last_clean_time" "$NOW"
        log "$label 完成"
        printf '{"ok":true,"msg":"%s完成","mode":"%s","time":"%s"}\n' "$label" "$mode" "$NOW"
    else
        log "$label 失败：游戏未安装"
        echo '{"ok":false,"error":"无畏契约未安装"}'
    fi
}

run_pubgmhd_and_report() {
    local mode="$1"
    local label
    if [ "$mode" = "light" ]; then
        clean_pubgmhd_light
        RET=$?
        label="和平精英轻度清理"
    else
        clean_pubgmhd_deep
        RET=$?
        label="和平精英深度清理"
    fi

    if [ $RET -eq 0 ]; then
        NOW="$(date '+%Y-%m-%d %H:%M:%S')"
        log "$label 完成"
        printf '{"ok":true,"msg":"%s完成","mode":"%s","time":"%s"}\n' "$label" "$mode" "$NOW"
    else
        log "$label 失败：游戏未安装"
        echo '{"ok":false,"error":"和平精英未安装"}'
    fi
}

case "$ARG1" in
    inotify)
        optimize_inotify
        ;;
    light)
        run_and_report "light"
        ;;
    deep|"")
        run_and_report "deep"
        ;;
    pubgmhd_light)
        run_pubgmhd_and_report "light"
        ;;
    pubgmhd_deep)
        run_pubgmhd_and_report "deep"
        ;;
    sgame_deep)
        run_simple clean_sgame_deep "王者荣耀清理" "王者荣耀"
        ;;
    cf_deep)
        run_simple clean_cf_deep "穿越火线手游清理" "穿越火线手游"
        ;;
    delta_cn_deep)
        clean_delta_for "com.tencent.tmgp.dfm"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "三角洲(国服)清理 完成"
            printf '{"ok":true,"msg":"三角洲(国服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"三角洲国服未安装"}'
        fi
        ;;
    delta_tw_deep)
        clean_delta_for "com.garena.game.df"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "三角洲(台服)清理 完成"
            printf '{"ok":true,"msg":"三角洲(台服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"三角洲台服未安装"}'
        fi
        ;;
    delta_global_deep)
        clean_delta_for "com.proxima.dfm"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "三角洲(国际服)清理 完成"
            printf '{"ok":true,"msg":"三角洲(国际服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"三角洲国际服未安装"}'
        fi
        ;;
    arena_cn_deep)
        clean_arena_for "com.tencent.mf.uam"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "暗区突围(国服)清理 完成"
            printf '{"ok":true,"msg":"暗区突围(国服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"暗区突围国服未安装"}'
        fi
        ;;
    arena_global_deep)
        clean_arena_for "com.proximabeta.mf.uamo"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "暗区突围(国际服)清理 完成"
            printf '{"ok":true,"msg":"暗区突围(国际服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"暗区突围国际服未安装"}'
        fi
        ;;
    arena_tw_deep)
        clean_arena_for "com.tw.mf.uamo.kbinstaller"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "暗区突围(台服)清理 完成"
            printf '{"ok":true,"msg":"暗区突围(台服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"暗区突围台服未安装"}'
        fi
        ;;
    arena_vn_deep)
        clean_arena_for "com.vng.mf.uamo"
        if [ $? -eq 0 ]; then
            NOW="$(date '+%Y-%m-%d %H:%M:%S')"
            log "暗区突围(越南服)清理 完成"
            printf '{"ok":true,"msg":"暗区突围(越南服)清理完成","time":"%s"}\n' "$NOW"
        else
            echo '{"ok":false,"error":"暗区突围越南服未安装"}'
        fi
        ;;
    cod_deep)
        run_simple clean_cod_deep "使命召唤手游清理" "使命召唤手游"
        ;;
    *)
        echo '{"ok":false,"error":"unknown mode"}'
        exit 1
        ;;
esac

exit 0
