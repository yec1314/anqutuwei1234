#!/system/bin/sh
# 下载器选择库（共享脚本）
# 作者: 呆呆 | QQ:891354018 | 群:774886621
# 兼容 curl + wget + busybox/toybox wget，按优先级自动挑选可用工具
#
# 用法:
#   . "$MOD_DIR/scripts/lib_curl.sh"
#   CURL_BIN=$(pick_curl)              # 兼容老接口：找 curl
#   DL=$(pick_downloader)              # 新接口：找任意可用下载器，输出 "type|path"
#   smart_download <url> <out_file>    # 推荐：自动 curl→wget 兜底，含 DNS / IP 兜底
#   list_curl_candidates               # 列出 curl 候选（JSON）
#   list_downloader_candidates         # 列出全部下载器候选（JSON，含 wget）
#
# settings.conf:
#   downloader_mode = auto | curl | wget
#       auto  - 自动按优先级（curl 优先，失败 wget 兜底）
#       curl  - 强制使用 curl，下方 curl_custom_path 指定路径
#       wget  - 强制使用 wget，下方 wget_custom_path 指定路径
#   curl_custom_path = /system/bin/curl
#   wget_custom_path = /system/bin/wget
#   curl_mode (兼容老配置) = auto | manual

[ -z "$MOD_DIR" ] && MOD_DIR="/data/adb/modules/webui_info"
[ -z "$WEBUI_SETTINGS" ] && . "$MOD_DIR/scripts/lib_paths.sh"
SETTINGS_FILE="${SETTINGS_FILE:-$WEBUI_SETTINGS}"

DNS_SERVERS_DEFAULT="223.5.5.5,114.114.114.114,119.29.29.29,8.8.8.8"

CURL_CANDIDATES="
$MOD_DIR/curl/curl
/odm/bin/curl
/system/bin/curl
/system/xbin/curl
/vendor/bin/curl
/data/user/0/bin.mt.plus.canary/files/term/bin/curl
/data/user/0/bin.mt.plus/files/term/bin/curl
"

WGET_CANDIDATES="
/system/bin/wget
/system/xbin/wget
/vendor/bin/wget
/data/adb/magisk/busybox
/data/adb/ksu/bin/busybox
/system/bin/toybox
/system/bin/busybox
"

_get_setting() {
    [ -f "$SETTINGS_FILE" ] || return
    grep "^$1=" "$SETTINGS_FILE" 2>/dev/null | head -1 | cut -d'=' -f2-
}

# ============ 工具检测 ============
test_curl_works() {
    local bin="$1"
    [ -z "$bin" ] && return 1
    [ ! -x "$bin" ] && [ "$bin" != "curl" ] && return 1
    local out
    out=$("$bin" --version 2>&1)
    [ -z "$out" ] && return 1
    case "$out" in
        *"CANNOT LINK"*|*"cannot locate"*|*"not found"*|*"No such file"*) return 1 ;;
    esac
    case "$out" in
        *curl*) return 0 ;;
        *) return 1 ;;
    esac
}

# 测试 wget 能不能跑（独立 wget / busybox wget / toybox wget 通吃）
test_wget_works() {
    local bin="$1"
    [ -z "$bin" ] && return 1
    [ ! -x "$bin" ] && [ "$bin" != "wget" ] && return 1
    case "$bin" in
        */busybox|*/toybox)
            "$bin" wget --help 2>&1 | grep -qiE "wget|usage" || return 1
            return 0 ;;
        *)
            local out
            out=$("$bin" --help 2>&1 | head -1)
            case "$out" in
                *"CANNOT LINK"*|*"cannot locate"*|*"not found"*) return 1 ;;
            esac
            "$bin" --help 2>&1 | grep -qiE "wget|usage" && return 0
            return 1 ;;
    esac
}

curl_has_dns_servers() {
    "$1" --help all 2>&1 | grep -q -- "--dns-servers"
}

# 读三档模式（auto/curl/wget），兼容老配置（curl_mode=auto/manual）
_get_downloader_mode() {
    local m
    m=$(_get_setting downloader_mode)
    if [ -n "$m" ]; then
        echo "$m"
        return
    fi
    # 老配置兼容
    m=$(_get_setting curl_mode)
    case "$m" in
        manual) echo "curl" ;;       # 老 manual 视为强制 curl
        auto|"") echo "auto" ;;
        *) echo "auto" ;;
    esac
}

# ============ pick_curl（保留兼容）============
pick_curl() {
    local mode
    mode=$(_get_downloader_mode)

    if [ "$mode" = "curl" ]; then
        local custom
        custom=$(_get_setting curl_custom_path)
        if [ -n "$custom" ] && test_curl_works "$custom"; then
            echo "$custom"; return 0
        fi
        return 1
    fi

    # mode=wget 时不选 curl
    [ "$mode" = "wget" ] && return 1

    local c
    for c in $CURL_CANDIDATES; do
        if test_curl_works "$c"; then echo "$c"; return 0; fi
    done
    if command -v curl >/dev/null 2>&1 && test_curl_works "curl"; then
        echo "curl"; return 0
    fi
    return 1
}

# ============ pick_wget ============
# 输出："独立 wget" -> "wget|/path"
#       "busybox/toybox wget" -> "wget_bb|/path"  （调用方式 $bin wget ...）
pick_wget() {
    local mode
    mode=$(_get_downloader_mode)

    if [ "$mode" = "wget" ]; then
        local custom
        custom=$(_get_setting wget_custom_path)
        if [ -n "$custom" ] && test_wget_works "$custom"; then
            case "$custom" in
                */busybox|*/toybox) echo "wget_bb|$custom" ;;
                *) echo "wget|$custom" ;;
            esac
            return 0
        fi
        return 1
    fi

    # mode=curl 时不走 wget 兜底
    [ "$mode" = "curl" ] && return 1

    local c
    for c in $WGET_CANDIDATES; do
        case "$c" in
            */busybox|*/toybox)
                if test_wget_works "$c"; then echo "wget_bb|$c"; return 0; fi ;;
            *)
                if test_wget_works "$c"; then echo "wget|$c"; return 0; fi ;;
        esac
    done
    if command -v wget >/dev/null 2>&1 && test_wget_works "wget"; then
        echo "wget|wget"; return 0
    fi
    return 1
}

# ============ pick_downloader ============
# 统一入口：按 mode 决定优先级
# auto  - curl 优先，失败 wget 兜底
# curl  - 只用 curl
# wget  - 只用 wget
pick_downloader() {
    local mode
    mode=$(_get_downloader_mode)

    case "$mode" in
        curl)
            local p
            p=$(pick_curl)
            [ -n "$p" ] && { echo "curl|$p"; return 0; }
            return 1 ;;
        wget)
            pick_wget ;;
        *)
            local p
            p=$(pick_curl)
            if [ -n "$p" ]; then echo "curl|$p"; return 0; fi
            pick_wget ;;
    esac
}

# ============ 候选列表 ============
list_curl_candidates() {
    local mode current custom
    mode=$(_get_setting curl_mode);  [ -z "$mode" ] && mode="auto"
    custom=$(_get_setting curl_custom_path)
    current=$(pick_curl)

    printf '{"ok":true,"mode":"%s","custom_path":"%s","current":"%s","candidates":[' \
        "$mode" "$custom" "$current"

    local first=1 c
    for c in $CURL_CANDIDATES; do
        local exists="false" works="false" ver=""
        if [ -e "$c" ]; then
            exists="true"
            if test_curl_works "$c"; then
                works="true"
                ver=$("$c" --version 2>/dev/null | head -1 | tr -d '"\\')
            else
                ver=$("$c" --version 2>&1 | head -1 | tr -d '"\\' | head -c 100)
            fi
        fi
        [ $first -eq 0 ] && printf ','
        printf '{"path":"%s","exists":%s,"works":%s,"version":"%s"}' \
            "$c" "$exists" "$works" "$ver"
        first=0
    done
    printf ']}'
}

# 列出 wget 候选（JSON）
list_wget_candidates() {
    local current
    current=$(pick_wget)
    printf '{"ok":true,"current":"%s","candidates":[' "$current"
    local first=1 c
    for c in $WGET_CANDIDATES; do
        local exists="false" works="false" kind="wget" ver=""
        case "$c" in
            */busybox|*/toybox) kind="wget_bb" ;;
        esac
        if [ -e "$c" ]; then
            exists="true"
            if test_wget_works "$c"; then
                works="true"
                if [ "$kind" = "wget_bb" ]; then
                    ver=$("$c" --help 2>&1 | head -1 | tr -d '"\\' | head -c 80)
                else
                    ver=$("$c" --version 2>/dev/null | head -1 | tr -d '"\\')
                    [ -z "$ver" ] && ver=$("$c" --help 2>&1 | head -1 | tr -d '"\\' | head -c 80)
                fi
            fi
        fi
        [ $first -eq 0 ] && printf ','
        printf '{"path":"%s","kind":"%s","exists":%s,"works":%s,"version":"%s"}' \
            "$c" "$kind" "$exists" "$works" "$ver"
        first=0
    done
    printf ']}'
}

# ============ 智能下载（统一入口）============
# 用法: smart_download <url> <out_file>
# 返回 0 = 成功（out_file 非空），非 0 = 失败
# 优先 curl（含 DNS / IP 兜底），失败则 wget
smart_download() {
    local url="$1" out_file="$2"
    local err_log="${out_file}.err"

    # ---- 第一档：curl ----
    local CURL_BIN
    CURL_BIN=$(pick_curl)
    if [ -n "$CURL_BIN" ]; then
        "$CURL_BIN" -sL --max-time 15 -A "Mozilla/5.0 CITADEL" "$url" -o "$out_file" 2>"$err_log"
        if [ -s "$out_file" ]; then rm -f "$err_log"; return 0; fi

        # DNS 兜底
        if [ -s "$err_log" ] && grep -qiE "Could not resolve|resolve host" "$err_log"; then
            if curl_has_dns_servers "$CURL_BIN"; then
                "$CURL_BIN" -sL --max-time 15 -A "Mozilla/5.0 CITADEL" \
                    --dns-servers "$DNS_SERVERS_DEFAULT" \
                    "$url" -o "$out_file" 2>"$err_log"
                if [ -s "$out_file" ]; then rm -f "$err_log"; return 0; fi
            fi
        fi

        # gitee IP 直连兜底
        case "$url" in
            *gitee.com*)
                "$CURL_BIN" -sL --max-time 15 -A "Mozilla/5.0 CITADEL" \
                    --resolve gitee.com:443:180.76.198.225 \
                    --resolve gitee.com:443:180.76.199.13 \
                    "$url" -o "$out_file" 2>"$err_log"
                if [ -s "$out_file" ]; then rm -f "$err_log"; return 0; fi ;;
        esac
    fi

    # ---- 第二档：wget ----
    local WGET_INFO
    WGET_INFO=$(pick_wget)
    if [ -n "$WGET_INFO" ]; then
        local kind="${WGET_INFO%%|*}"
        local wbin="${WGET_INFO#*|}"
        if [ "$kind" = "wget_bb" ]; then
            "$wbin" wget -q -T 15 -O "$out_file" "$url" 2>"$err_log" \
                || "$wbin" wget --no-check-certificate -q -T 15 -O "$out_file" "$url" 2>"$err_log"
        else
            "$wbin" -q --timeout=15 -O "$out_file" "$url" 2>"$err_log" \
                || "$wbin" --no-check-certificate -q --timeout=15 -O "$out_file" "$url" 2>"$err_log"
        fi
        if [ -s "$out_file" ]; then rm -f "$err_log"; return 0; fi
    fi

    rm -f "$err_log"
    return 1
}

# 老接口（保留向后兼容）
smart_curl_download() { smart_download "$@"; }
