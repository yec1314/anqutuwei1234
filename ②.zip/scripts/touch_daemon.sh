#!/system/bin/sh
# 触控采样率循环守护脚本
# 每隔10秒重新执行一次触控命令，防止系统重置
# 作者: 呆呆 | QQ:891354018 | 群:774886621

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
PROFILE_FILE="$WEBUI_TOUCH_PROFILE"
DAEMON_PIDFILE="$WEBUI_TOUCH_DAEMON_PID"
INTERVAL=10

# 写入自身 PID，供 touch_rate.sh 管理
echo "$$" > "$DAEMON_PIDFILE"

while true; do
    if [ -f "$PROFILE_FILE" ]; then
        profile=$(cat "$PROFILE_FILE" 2>/dev/null)
        case "$profile" in
            125) touchHidlTest -c wo 0 26 0 2>/dev/null ;;
            240) touchHidlTest -c wo 0 26 1 2>/dev/null ;;
            360) touchHidlTest -c wo 0 26 12c 2>/dev/null ;;
            600) touchHidlTest -c wo 0 26 258 2>/dev/null ;;
            241) touchHidlTest -c wo 0 182 240 2>/dev/null ;;
            361) touchHidlTest -c wo 0 26 c 2>/dev/null ;;
            362) touchHidlTest -c wo 0 182 360 2>/dev/null ;;
            default) break ;;
        esac
    else
        break
    fi
    sleep $INTERVAL
done

# 退出时清理 PID 文件
rm -f "$DAEMON_PIDFILE" 2>/dev/null
