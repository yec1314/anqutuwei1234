#!/system/bin/sh
# WiFi MAC 地址管理
# 作者: 呆呆 | QQ:891354018 | 群:774886621
# 用法:
#   sh mac.sh info             查看当前/原始 MAC
#   sh mac.sh random           随机生成新 MAC
#   sh mac.sh set <mac>        设置自定义 MAC（格式 xx:xx:xx:xx:xx:xx）
#   sh mac.sh restore          恢复原始 MAC

MOD_DIR="/data/adb/modules/webui_info"
. "$MOD_DIR/scripts/lib_paths.sh"
webui_init_dirs
. "$MOD_DIR/scripts/lib_log.sh"
init_log "mac"

BACKUP_FILE="$WEBUI_BACKUP_DIR/wlan_mac_orig"
APPLIED_FILE="$WEBUI_BACKUP_DIR/wlan_mac_applied"
IFACE_FILE="$WEBUI_BACKUP_DIR/wlan_mac_iface"

# 检测 WiFi 网卡名（wlan0 / wlan1 / sta0 等）
detect_iface() {
    local cached
    if [ -f "$IFACE_FILE" ]; then
        cached=$(cat "$IFACE_FILE" 2>/dev/null | tr -d ' \n\r')
        if [ -n "$cached" ] && [ -d "/sys/class/net/$cached" ]; then
            echo "$cached"
            return 0
        fi
    fi
    # 优先 wlan0
    for n in wlan0 wlan1 wlan2 sta0; do
        [ -d "/sys/class/net/$n" ] && { echo "$n"; echo "$n" > "$IFACE_FILE"; return 0; }
    done
    # 兜底：扫描 /sys/class/net 找 wireless 目录
    local iface
    for d in /sys/class/net/*/wireless; do
        [ -d "$d" ] || continue
        iface=$(basename "$(dirname "$d")")
        echo "$iface"
        echo "$iface" > "$IFACE_FILE"
        return 0
    done
    return 1
}

# 读取当前 MAC（从 /sys 读取，最准确）
read_current_mac() {
    local iface="$1"
    [ -z "$iface" ] && return 1
    cat "/sys/class/net/$iface/address" 2>/dev/null | tr 'A-Z' 'a-z'
}

# 备份原始 MAC（仅首次）
backup_orig() {
    local iface="$1"
    if [ ! -f "$BACKUP_FILE" ]; then
        local mac
        mac=$(read_current_mac "$iface")
        if [ -n "$mac" ]; then
            mkdir -p "$(dirname "$BACKUP_FILE")" 2>/dev/null
            echo "$mac" > "$BACKUP_FILE"
            log_json "备份原始 MAC: $mac"
        fi
    fi
}

# 验证 MAC 格式
is_valid_mac() {
    local mac="$1"
    echo "$mac" | grep -qiE '^[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}$'
}

# 应用 MAC（核心：down → set → up）
apply_mac() {
    local iface="$1"
    local mac="$2"
    [ -z "$iface" ] || [ -z "$mac" ] && return 1

    # 转小写
    mac=$(echo "$mac" | tr 'A-Z' 'a-z')

    # 确保单播 + 本地管理位（避免组播 MAC，第一字节 bit0=0, bit1=1）
    # 这里只校验 unicast，bit1 由用户/随机生成器保证
    local first_byte
    first_byte=$(echo "$mac" | cut -d: -f1)
    local first_int
    first_int=$(printf '%d' "0x$first_byte" 2>/dev/null)
    if [ -n "$first_int" ]; then
        # bit0=1 是组播地址，强制清零
        if [ "$((first_int & 1))" -eq 1 ]; then
            first_int=$((first_int & 254))
            local fixed_first
            fixed_first=$(printf '%02x' "$first_int")
            mac="${fixed_first}:$(echo "$mac" | cut -d: -f2-)"
        fi
    fi

    # down 接口
    ip link set "$iface" down 2>/dev/null
    sleep 0.2 2>/dev/null || sleep 1

    # 设置 MAC
    local ok=0
    ip link set "$iface" address "$mac" 2>/dev/null && ok=1
    [ "$ok" = "0" ] && ifconfig "$iface" hw ether "$mac" 2>/dev/null && ok=1

    # up 接口
    ip link set "$iface" up 2>/dev/null

    # 验证
    sleep 0.3 2>/dev/null || sleep 1
    local actual
    actual=$(read_current_mac "$iface")
    if [ "$actual" = "$mac" ]; then
        echo "$mac" > "$APPLIED_FILE"
        return 0
    fi
    return 1
}

# 生成随机 MAC（合法的本地管理单播地址）
random_mac() {
    # 第一字节: bit0=0 (单播), bit1=1 (本地管理) → 末两位是 10 → x2/x6/xA/xE
    # 取常见的小米/三星/华为厂商前缀模仿真实设备
    local prefixes="02:00:00 06:00:00 0a:00:00 9c:fb:d5 a4:50:46 b8:c9:b5 d4:6e:0e fc:64:ba"
    local pcount=0
    for p in $prefixes; do pcount=$((pcount + 1)); done
    local idx=$(( $(date +%N 2>/dev/null || echo "$$") % pcount + 1 ))
    local prefix=""
    local i=0
    for p in $prefixes; do
        i=$((i + 1))
        [ "$i" = "$idx" ] && { prefix="$p"; break; }
    done
    [ -z "$prefix" ] && prefix="02:00:00"

    # 后三段随机
    local b1 b2 b3
    b1=$(printf '%02x' $(( $(od -An -N1 -tu1 /dev/urandom 2>/dev/null | tr -d ' ') % 256 )))
    b2=$(printf '%02x' $(( $(od -An -N1 -tu1 /dev/urandom 2>/dev/null | tr -d ' ') % 256 )))
    b3=$(printf '%02x' $(( $(od -An -N1 -tu1 /dev/urandom 2>/dev/null | tr -d ' ') % 256 )))
    [ -z "$b1" ] && b1=$(printf '%02x' $(($$ % 256)))
    [ -z "$b2" ] && b2=$(printf '%02x' $((($$ * 7) % 256)))
    [ -z "$b3" ] && b3=$(printf '%02x' $((($$ * 13) % 256)))

    echo "${prefix}:${b1}:${b2}:${b3}"
}

# ===== 命令 =====
cmd_info() {
    local iface
    iface=$(detect_iface)
    if [ -z "$iface" ]; then
        echo '{"ok":false,"error":"未检测到 WiFi 网卡"}'
        return
    fi

    backup_orig "$iface"

    local current orig applied modified
    current=$(read_current_mac "$iface")
    orig=$(cat "$BACKUP_FILE" 2>/dev/null | tr -d ' \n\r')
    applied=$(cat "$APPLIED_FILE" 2>/dev/null | tr -d ' \n\r')
    [ -z "$current" ] && current="-"
    [ -z "$orig" ] && orig="$current"

    if [ -n "$applied" ] && [ "$applied" != "$orig" ]; then
        modified="true"
    else
        modified="false"
    fi

    printf '{"ok":true,"iface":"%s","current":"%s","original":"%s","modified":%s}\n' \
        "$iface" "$current" "$orig" "$modified"
}

cmd_random() {
    local iface
    iface=$(detect_iface)
    if [ -z "$iface" ]; then
        echo '{"ok":false,"error":"未检测到 WiFi 网卡"}'
        return
    fi
    backup_orig "$iface"

    local mac
    mac=$(random_mac)
    if ! is_valid_mac "$mac"; then
        echo '{"ok":false,"error":"随机生成的 MAC 格式异常"}'
        return
    fi

    if apply_mac "$iface" "$mac"; then
        log_json "随机 MAC 已应用: $mac (iface=$iface)"
        printf '{"ok":true,"mac":"%s","msg":"已应用随机 MAC"}\n' "$mac"
    else
        printf '{"ok":false,"error":"应用失败，可能需要 SELinux 宽容或缺少 ip 命令"}\n'
    fi
}

cmd_set() {
    local mac="$1"
    if [ -z "$mac" ]; then
        echo '{"ok":false,"error":"缺少 MAC 参数"}'
        return
    fi
    if ! is_valid_mac "$mac"; then
        echo '{"ok":false,"error":"MAC 格式无效，应为 xx:xx:xx:xx:xx:xx"}'
        return
    fi

    local iface
    iface=$(detect_iface)
    if [ -z "$iface" ]; then
        echo '{"ok":false,"error":"未检测到 WiFi 网卡"}'
        return
    fi
    backup_orig "$iface"

    if apply_mac "$iface" "$mac"; then
        log_json "自定义 MAC 已应用: $mac (iface=$iface)"
        printf '{"ok":true,"mac":"%s","msg":"已应用自定义 MAC"}\n' "$mac"
    else
        echo '{"ok":false,"error":"应用失败"}'
    fi
}

cmd_restore() {
    local iface
    iface=$(detect_iface)
    if [ -z "$iface" ]; then
        echo '{"ok":false,"error":"未检测到 WiFi 网卡"}'
        return
    fi

    local orig
    orig=$(cat "$BACKUP_FILE" 2>/dev/null | tr -d ' \n\r')
    if [ -z "$orig" ]; then
        echo '{"ok":false,"error":"无原始 MAC 备份"}'
        return
    fi

    if apply_mac "$iface" "$orig"; then
        rm -f "$APPLIED_FILE"
        log_json "已恢复原始 MAC: $orig"
        printf '{"ok":true,"mac":"%s","msg":"已恢复原始 MAC"}\n' "$orig"
    else
        echo '{"ok":false,"error":"恢复失败"}'
    fi
}

ACTION="$1"
case "$ACTION" in
    info)    cmd_info ;;
    random)  cmd_random ;;
    set)     cmd_set "$2" ;;
    restore) cmd_restore ;;
    *)       echo '{"ok":false,"error":"unknown action: '"$ACTION"'"}' ;;
esac
